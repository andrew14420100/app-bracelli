const CACHE = 'bracelli-shell-v8';
const SHELL = ['./', './index.html', './offline.html', './src/styles.css', './src/tokens.css', './src/app.js', './src/ui-shell.js', './src/pwa.js', './src/identity.js', './src/config.js', './src/content.js', './src/catalog-data.js', './src/catalog-ui.js', './src/explorer.js', './src/trial-data.js', './src/trial-ui.js', './src/shared/explorer-engine.js', './src/shared/explorer-widget.js', './src/shared/explorer-network.js', './src/shared/explorer.css', './manifest.webmanifest', './assets/bracelli-logo.png', './assets/icon-192.png', './assets/icon-512.png', './assets/apple-touch-icon.png'];
const allowed = new Set(SHELL.map(path => new URL(path, self.registration.scope).href));
self.addEventListener('install', event => {
  // One complete version. Failed installation never replaces the active worker.
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL)).catch(async error => {await caches.delete(CACHE);throw error;}));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('bracelli-shell-v') && key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('message', event => {
  if (event.data?.type !== 'BC_APPLY_UPDATE') return;
  event.waitUntil(self.clients.matchAll({type:'window', includeUncontrolled:true}).then(clients => {
    const scoped = clients.filter(client => client.url.startsWith(self.registration.scope));
    if (scoped.length > 1) event.source?.postMessage({type:'BC_UPDATE_BLOCKED'});
    else return self.skipWaiting();
  }));
});
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);url.hash = '';
  if (event.request.method !== 'GET' || url.origin !== self.location.origin) return;
  // Exact shell allowlist. REST, query strings, admin and personal submissions never enter Cache Storage.
  if (!allowed.has(url.href)) return;
  event.respondWith(caches.open(CACHE).then(async cache => {
    const cached = await cache.match(event.request);
    if (cached) return cached;
    try {return await fetch(event.request);}
    catch {return await cache.match(new URL('./offline.html', self.registration.scope)) || Response.error();}
  }));
});
