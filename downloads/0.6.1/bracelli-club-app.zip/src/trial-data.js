export function normalizePhone(value) {
  if(typeof value!=='string'||!/^\+?[0-9 ()\-.]+$/.test(value))return '';
  const phone=value.replace(/[ ()\-.]/g,'');return /^\+?[0-9]{7,15}$/.test(phone)?phone:'';
}
export function safeLink(value) {
  try{const url=new URL(value);return ['http:','https:'].includes(url.protocol)&&!url.username&&!url.password?url.href:'';}catch{return '';}
}
export function ageBands(data,disciplineId,courseId) {
  return [...new Set(data.courses.filter(course=>courseId?course.id===Number(courseId):course.disciplineId===Number(disciplineId)).map(course=>course.ageBand).filter(Boolean))];
}
export function validateTrial(data,form) {
  const errors={};
  for(const [key,label] of [['first_name','nome'],['last_name','cognome']])if(typeof form[key]!=='string'||!form[key].trim()||form[key].length>80)errors[key]=`Inserisci il ${label} del referente adulto (massimo 80 caratteri).`;
  if(typeof form.email!=='string'||form.email.length>254||!/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(form.email))errors.email='Inserisci un indirizzo email valido.';
  if(!normalizePhone(form.phone))errors.phone='Inserisci un telefono valido (7–15 cifre).';
  const discipline=data.disciplines.find(item=>item.id===Number(form.discipline_id));
  const course=data.courses.find(item=>item.id===Number(form.course_id));
  if(!discipline)errors.discipline_id='Seleziona una disciplina con prova disponibile.';
  if(form.course_id && (!course||course.disciplineId!==Number(form.discipline_id)))errors.course_id='Seleziona un corso della disciplina scelta.';
  const bands=ageBands(data,form.discipline_id,form.course_id);
  if(bands.length&&!bands.includes(form.age_band))errors.age_band='Seleziona la fascia d’età del partecipante.';
  if(!Number.isInteger(Number(form.preferred_day))||Number(form.preferred_day)<0||Number(form.preferred_day)>7)errors.preferred_day='Seleziona un giorno valido.';
  if(typeof form.message!=='string'||form.message.length>2000)errors.message='Il messaggio può contenere al massimo 2000 caratteri.';
  if(!form.privacy_acknowledged)errors.privacy_acknowledged='Conferma di aver letto l’informativa privacy.';
  if(form.website)errors.website='Invio non accettato.';
  return errors;
}
export function validateTrialConfig(data) {
  if(!data || typeof data.enabled!=='boolean'||!data.contacts||!Array.isArray(data.disciplines)||!Array.isArray(data.courses))throw Error('Modulo non disponibile');
  if(!['phone','whatsapp','email','address','directions','office_hours'].every(key=>typeof data.contacts[key]==='string'))throw Error('Contatti non disponibili');
  if(data.enabled && (!data.privacy||typeof data.privacy.text!=='string'||typeof data.privacy.version!=='string'||typeof data.token!=='string'))throw Error('Modulo non disponibile');
  if(!data.disciplines.every(item=>Number.isInteger(item.id)&&item.id>0&&typeof item.name==='string')||!data.courses.every(item=>Number.isInteger(item.id)&&Number.isInteger(item.disciplineId)&&typeof item.name==='string'&&typeof item.ageBand==='string'&&data.disciplines.some(d=>d.id===item.disciplineId)))throw Error('Attività non disponibili');
  return data;
}
