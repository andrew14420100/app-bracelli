import {config} from './config.js';
import {safeMedia} from './catalog-data.js';
async function loadIdentity(){try{
 const response=await fetch(`${config.apiBase}/identity`,{credentials:config.credentials,cache:'no-store',signal:AbortSignal.timeout(8000)});
 if(response.ok){const identity=await response.json();if(['gold','warm_gold'].includes(identity.accent))document.body.dataset.bracelliAccent=identity.accent;if(identity.compact===true)document.body.classList.add('compact-brand');
  const root=document.querySelector('#club-public-info');if(root){if(typeof identity.summary==='string'&&identity.summary){const p=document.createElement('p');p.textContent=identity.summary;p.className='description';root.append(p);}if(Array.isArray(identity.images)){for(const url of identity.images.slice(0,8)){const src=safeMedia(url,location.origin);if(src){const img=document.createElement('img');img.src=src;img.alt='Bracelli Club';img.loading='lazy';img.decoding='async';img.width=640;img.height=400;img.className='catalog-photo';root.append(img);const highlights=document.querySelector('#home-public-images');if(highlights&&highlights.children.length<3){const preview=img.cloneNode();preview.alt='Fotografia del centro pubblicata dalla redazione';highlights.append(preview);document.querySelector('#home-highlights').hidden=false;}}}}}
 }
}catch{/* Optional branding never blocks existing application workflows. */}

}
loadIdentity();
