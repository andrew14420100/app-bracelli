const nav = document.querySelector('.bottom-nav');
const links = [...nav.querySelectorAll('a')];
const sections = [...document.querySelectorAll('main > section[id]')];
function destination(hash) {
  const key = hash.replace(/^#/, '').split(/[/?]/)[0];
  if (['discipline', 'course', 'instructor', 'instructors', 'disciplines'].includes(key)) return 'disciplines';
  return ['home', 'explorer', 'schedule', 'contacts'].includes(key) ? key : '';
}
function active(id) {
  for (const link of links) {
    if (link.hash === `#${id}`) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  }
}
function route() {
  active(destination(location.hash) || (!location.hash ? 'home' : ''));
  const section = document.getElementById(location.hash.slice(1));
  if (section?.matches('main > section')) {
    section.classList.remove('route-enter');
    requestAnimationFrame(() => section.classList.add('route-enter'));
  }
}
window.addEventListener('hashchange', route);
route();
// Scroll position, rather than a second menu, determines the selected destination.
let frame;
window.addEventListener('scroll', () => {
  if (frame) return;
  frame = requestAnimationFrame(() => {
    frame = null;
    const offset = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--header-height')) + 100;
    const section = sections.filter(item => !item.hidden && item.getBoundingClientRect().top <= offset).at(-1);
    if (section) active(section.id === 'catalog-detail' ? 'disciplines' : destination(section.id));
  });
}, {passive: true});
const connection = document.querySelector('#connection-status');
function connectivity() {
  connection.hidden = navigator.onLine;
  connection.textContent = navigator.onLine ? '' : 'Sei offline. I contenuti già visualizzati possono essere superati. Orari, disponibilità e richieste richiedono una verifica online.';
  document.body.classList.toggle('is-offline', !navigator.onLine);
}
window.addEventListener('offline', connectivity);
window.addEventListener('online', connectivity);
connectivity();
