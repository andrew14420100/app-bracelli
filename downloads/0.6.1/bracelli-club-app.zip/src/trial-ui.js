import {config} from './config.js';
import {ageBands,normalizePhone,safeLink,validateTrial,validateTrialConfig} from './trial-data.js';
const node=(tag,text,className)=>{const element=document.createElement(tag);if(text!==undefined)element.textContent=text;if(className)element.className=className;return element;};
const action=(label,handler)=>{const button=node('button',label);button.type='button';button.onclick=handler;return button;};
const link=(text,href)=>{const a=node('a',text,'text-link');a.href=href;return a;};
const root=document.querySelector('#trial-panel'),contacts=document.querySelector('#contacts-panel');
let data,pending,generation=0,lastSubmission,busy=false;
async function load(){
  if(navigator.onLine===false)throw Error('Offline');
  const response=await fetch(`${config.apiBase}/trial-form`,{credentials:config.credentials,cache:'no-store',signal:AbortSignal.timeout(8000)});
  if(!response.ok||Number(response.headers.get('Age'))>0)throw Error('Modulo non disponibile');
  data=validateTrialConfig(await response.json());renderContacts();return data;
}
function renderContacts(){
  contacts.replaceChildren();const c=data.contacts;
  const phone=normalizePhone(c.phone);if(phone)contacts.append(link(`Telefono: ${c.phone}`,`tel:${phone}`));
  const whatsapp=normalizePhone(c.whatsapp);if(whatsapp&&/^\+[1-9]\d{6,14}$/.test(whatsapp)){const a=link('Scrivici su WhatsApp',`https://wa.me/${whatsapp.slice(1)}`);a.rel='noopener noreferrer';contacts.append(a);}
  if(typeof c.email==='string'&&/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(c.email))contacts.append(link(c.email,`mailto:${encodeURIComponent(c.email)}`));
  if(c.address){contacts.append(node('h3','Dove siamo'),node('p',c.address,'description'));}
  if(safeLink(c.directions)){const a=link('Indicazioni stradali',safeLink(c.directions));a.rel='noopener noreferrer';contacts.append(a);}
  if(c.office_hours)contacts.append(node('h3','Orari della segreteria'),node('p',c.office_hours,'description'));
  if(!c.phone&&!c.whatsapp&&!c.email&&!c.address&&!c.office_hours)contacts.append(node('p','I contatti del centro non sono ancora pubblicati.'));
  contacts.append(link('Richiedi una prova','#trial'));
}
function message(text){root.classList.remove('trial-confirmation');root.replaceChildren();const p=node('p',text);p.setAttribute('role','status');root.append(p);}
function initial(){message('Invia una richiesta alla segreteria per concordare una lezione di prova.');root.append(action('Apri modulo di richiesta',()=>{location.hash='trial';open();}));}
function readForm(form){
  const values={};for(const key of ['first_name','last_name','email','phone','discipline_id','course_id','age_band','preferred_day','message','website'])values[key]=form.elements[key]?.value || '';
  values.privacy_acknowledged=!!form.elements.privacy_acknowledged?.checked;return values;
}
async function open(){
  if(busy)return;
  const token=++generation;const oldForm=root.querySelector('form');const previous=oldForm?readForm(oldForm):null;const oldVersion=data?.privacy?.version;
  message('Caricamento del modulo aggiornato…');
  try{
    const fresh=pending ? await pending : await load();if(token!==generation)return;
    if(!fresh.enabled){message('Le richieste online non sono ancora disponibili. Usa i contatti pubblicati per contattare il centro.');return;}
    if(!fresh.disciplines.length){message('Non sono pubblicate attività con prova disponibile. Puoi contattare la segreteria dai contatti.');return;}
    renderForm(previous,oldVersion);
  }catch{if(token!==generation)return;message('Il modulo aggiornato non è disponibile. Controlla la connessione e riprova.');root.append(action('Riprova a caricare il modulo',open));}
}
function renderForm(previous,oldVersion){
  root.replaceChildren();const form=node('form',undefined,'trial-form');form.noValidate=true;const controls={};const errors=node('div',undefined,'trial-errors');errors.setAttribute('role','alert');errors.tabIndex=-1;form.append(errors);
  const intro=node('p','Inserisci soltanto i dati del referente adulto. Non indicare nomi del minore, dati sanitari o altri dettagli non necessari.');form.append(intro);
  function field(name,label,type='text',optional=false){
    const wrap=node('div',undefined,'trial-field');const id=`trial-${name}`;const caption=node('label',label+(optional?' (facoltativo)':''));caption.htmlFor=id;
    const input=node(type==='textarea'?'textarea':type==='select'?'select':'input');input.id=id;input.name=name;if(input.tagName==='INPUT')input.type=type;input.required=!optional;
    const error=node('p','','field-error');error.id=`${id}-error`;input.setAttribute('aria-describedby',error.id);wrap.append(caption,input,error);form.append(wrap);controls[name]={input,error,wrap,label};return input;
  }
  const first=field('first_name','Nome del referente adulto');first.maxLength=80;first.autocomplete='given-name';
  const last=field('last_name','Cognome del referente adulto');last.maxLength=80;last.autocomplete='family-name';
  const email=field('email','Email','email');email.maxLength=254;email.autocomplete='email';
  const phone=field('phone','Telefono','tel');phone.maxLength=30;phone.autocomplete='tel';phone.inputMode='tel';
  const discipline=field('discipline_id','Disciplina','select');discipline.add(new Option('Seleziona una disciplina',''));for(const item of data.disciplines)discipline.add(new Option(item.name,String(item.id)));
  const course=field('course_id','Corso','select',true),age=field('age_band','Fascia d’età del partecipante','select'),day=field('preferred_day','Giorno preferito','select',true);
  day.add(new Option('Nessuna preferenza','0'));for(const [index,label] of ['Lunedì','Martedì','Mercoledì','Giovedì','Venerdì','Sabato','Domenica'].entries())day.add(new Option(label,String(index+1)));
  const extra=field('message','Messaggio aggiuntivo','textarea',true);extra.rows=4;extra.maxLength=2000;
  const honeypot=field('website','Lascia vuoto questo campo','text',true);controls.website.wrap.hidden=true;honeypot.tabIndex=-1;honeypot.autocomplete='off';controls.website.wrap.setAttribute('aria-hidden','true');
  const policy=node('section',undefined,'privacy-notice');policy.append(node('h3','Informativa privacy'),node('p',data.privacy.text,'description'));
  if(safeLink(data.privacy.url)){const full=link('Leggi l’informativa completa',safeLink(data.privacy.url));full.target='_blank';full.rel='noopener noreferrer';policy.append(full);}form.append(policy);
  const ack=field('privacy_acknowledged','Ho preso visione dell’informativa privacy per la gestione della richiesta.','checkbox');ack.value='1';
  const submit=node('button','Invia richiesta di prova');submit.type='submit';const status=node('p','');status.setAttribute('role','status');form.append(submit,status,action('Ricarica modulo e informativa',open));
  function updateAge(){const old=age.value;const bands=ageBands(data,discipline.value,course.value);age.replaceChildren(new Option('Seleziona la fascia d’età',''));for(const label of bands)age.add(new Option(label,label));if(bands.includes(old))age.value=old;controls.age_band.wrap.hidden=!bands.length;age.required=!!bands.length;}
  function updateCourses(preset=''){course.replaceChildren(new Option('Nessun corso specifico',''));for(const item of data.courses.filter(item=>item.disciplineId===Number(discipline.value)))course.add(new Option(item.name,String(item.id)));if([...course.options].some(option=>option.value===preset))course.value=preset;updateAge();}
  const query=new URLSearchParams(location.hash.split('?')[1] || '');const d=query.get('discipline') || previous?.discipline_id || '';const c=query.get('course') || previous?.course_id || '';
  if([...discipline.options].some(option=>option.value===d))discipline.value=d;
  if(!discipline.value&&c){const selected=data.courses.find(item=>String(item.id)===c);if(selected)discipline.value=String(selected.disciplineId);}
  updateCourses(c);discipline.onchange=()=>updateCourses();course.onchange=updateAge;
  if(previous){for(const key of ['first_name','last_name','email','phone','message','preferred_day'])controls[key].input.value=previous[key];if([...age.options].some(option=>option.value===previous.age_band))age.value=previous.age_band;ack.checked=!!previous.privacy_acknowledged && oldVersion===data.privacy.version;}
  function showErrors(messages,generic='Controlla i campi indicati prima di inviare.'){
    errors.replaceChildren(node('p',generic));for(const value of Object.values(controls)){value.error.textContent='';value.input.removeAttribute('aria-invalid');}
    const list=node('ul');for(const [key,text] of Object.entries(messages)){const target=controls[key];if(!target)continue;target.error.textContent=text;target.input.setAttribute('aria-invalid','true');const item=node('li');const jump=action(`${target.label}: ${text}`,()=>target.input.focus());jump.className='error-jump';item.append(jump);list.append(item);}errors.append(list);errors.focus();
  }
  form.onsubmit=async event=>{
    event.preventDefault();if(busy)return;
    const values=readForm(form);const invalid=validateTrial(data,values);if(Object.keys(invalid).length){showErrors(invalid);return;}
    if(navigator.onLine===false){showErrors({},'Sei offline. La richiesta non viene accodata: riconnettiti e riprova.');return;}
    values.phone=normalizePhone(values.phone);values.discipline_id=Number(values.discipline_id);values.course_id=Number(values.course_id);values.preferred_day=Number(values.preferred_day);
    const signature=JSON.stringify(values);if(!lastSubmission||lastSubmission.signature!==signature)lastSubmission={signature,id:crypto.randomUUID()};
    const payload={...values,submission_id:lastSubmission.id,privacy_version:data.privacy.version,token:data.token};
    busy=true;window.dispatchEvent(new CustomEvent('bracelli:trial-busy',{detail:true}));submit.disabled=true;submit.textContent='Invio in corso…';status.textContent='Registrazione della richiesta…';errors.replaceChildren();
    try{
      const response=await fetch(`${config.apiBase}/trial-requests`,{method:'POST',credentials:config.credentials,cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(25000)});
      const result=await response.json();
      if(!response.ok){showErrors(result.data?.fields || {},result.message || 'Invio non riuscito. Riprova.');status.textContent='La richiesta non è stata confermata come ricevuta.';return;}
      if(result.received!==true)throw Error('Esito non verificato');
      lastSubmission=null;root.replaceChildren();root.classList.add('trial-confirmation');const heading=node('h3','Richiesta ricevuta');heading.tabIndex=-1;root.append(heading,node('p','La segreteria ti contatterà per concordare la prova. L’appuntamento non è ancora confermato.'),action('Invia una nuova richiesta',()=>{lastSubmission=null;open();}));heading.focus();
    }catch{showErrors({},'Non possiamo verificare l’esito. Puoi riprovare senza cambiare i dati: gli invii identici non creano richieste duplicate.');status.textContent='Esito da verificare.';}
    finally{busy=false;window.dispatchEvent(new CustomEvent('bracelli:trial-busy',{detail:false}));submit.disabled=false;submit.textContent='Invia richiesta di prova';}
  };
  root.append(form);const heading=document.querySelector('#trial-title');heading.focus({preventScroll:true});
}
if(root&&contacts){
  initial();pending=load().catch(()=>{contacts.replaceChildren(node('p','Contatti non disponibili. Riprova più tardi.'));}).finally(()=>{pending=null;});
  const route=()=>{if(/^#trial(?:\?|$)/.test(location.hash))open();};window.addEventListener('hashchange',route);route();
}
