/** Shared deterministic engine: WordPress preview and PWA use this exact module. No I/O. */
const reserved = new Set(['none','any']);
const isId = value => Number.isSafeInteger(value) && value > 0;
const normalize = value => String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase();
export function validateSettings(config) {
  if (!config || config.version !== 1 || !config.weights) throw Error('Configurazione Explorer non valida.');
  for (const key of ['goal','preference','day']) if (!Number.isInteger(config.weights[key]) || config.weights[key]<0 || config.weights[key]>20) throw Error('Pesi Explorer non validi.');
  if (['goal','preference','day'].every(key=>config.weights[key]===0)) throw Error('Almeno un peso deve essere positivo.');
  for (const key of ['goals','preferences']) {
    const rows=config[key];
    if (!Array.isArray(rows) || rows.length<1 || rows.length>30) throw Error('Categorie Explorer non valide.');
    const ids=new Set(),labels=new Set();
    for(const row of rows){
      if (!row || typeof row.id!=='string' || !/^[a-z][a-z0-9_-]{0,39}$/.test(row.id) || reserved.has(row.id) || typeof row.label!=='string' || !row.label.trim() || [...row.label].length>80 || ids.has(row.id) || labels.has(normalize(row.label))) throw Error('Categorie Explorer non valide.');
      ids.add(row.id);labels.add(normalize(row.label));
    }
  }
  return config;
}
export function validateAnswers(answers, config) {
  validateSettings(config);
  if (!answers || !['self','child'].includes(answers.recipient) || !Number.isInteger(answers.age) || answers.age<0 || answers.age>120) throw Error('Indica destinatario ed età valida (0–120 anni).');
  for (const key of ['goals','preferences']) {
    const ids=new Set(config[key].map(row=>row.id));if(key==='preferences')ids.add('none');
    if (!Array.isArray(answers[key]) || !answers[key].length || new Set(answers[key]).size!==answers[key].length || answers[key].some(id=>!ids.has(id))) throw Error('Le opzioni sono cambiate o mancano risposte. Verifica obiettivi e preferenze.');
  }
  if (answers.preferences.includes('none') && answers.preferences.length!==1) throw Error('Nessuna preferenza non può essere combinata con altre preferenze.');
  if (!Array.isArray(answers.days) || new Set(answers.days).size!==answers.days.length || answers.days.some(day=>!Number.isInteger(day)||day<1||day>7)) throw Error('Giorni non validi.');
  return answers;
}
export function ageCompatible(course, age) {
  const range=course?.ageRange;
  return !!range && Number.isInteger(range.min) && Number.isInteger(range.max) && range.min>=0 && range.max<=120 && range.min<=range.max && Number.isInteger(age) && age>=range.min && age<=range.max;
}
const isPublic = record => record && (record.status===undefined || record.status==='publish') && !record.hidden && !record.password;
export function recommend(catalog, answers, config=catalog?.explorer) {
  validateAnswers(answers,config);
  if (!catalog || !['disciplines','courses','instructors','schedule'].every(key=>Array.isArray(catalog[key]))) throw Error('Catalogo non disponibile.');
  for(const key of ['disciplines','courses','instructors','schedule']){
    if(catalog[key].some(row=>!row || !isId(row.id)) || new Set(catalog[key].map(row=>row.id)).size!==catalog[key].length) throw Error('Catalogo non coerente.');
  }
  const disciplines=new Map(catalog.disciplines.filter(isPublic).map(row=>[row.id,row]));
  const instructors=new Set(catalog.instructors.filter(isPublic).map(row=>row.id));
  const courses=new Map(catalog.courses.filter(course=>isPublic(course) && (course.active===undefined || course.active===true) && disciplines.has(course.disciplineId) && ageCompatible(course,answers.age)).map(row=>[row.id,row]));
  const grouped=new Map();for(const course of courses.values()){if(!grouped.has(course.disciplineId))grouped.set(course.disciplineId,[]);grouped.get(course.disciplineId).push(course);}
  const availableDays=new Map();
  for(const slot of catalog.schedule){
    const course=courses.get(slot.courseId);
    if (!course || !isPublic(slot) || slot.suspended || !instructors.has(slot.instructorId) || !course.instructorIds?.includes(slot.instructorId) || !Number.isInteger(slot.day) || slot.day<1 || slot.day>7 || !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(slot.start) || !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(slot.end) || slot.end<=slot.start) continue;
    if(!availableDays.has(course.disciplineId))availableDays.set(course.disciplineId,new Set());availableDays.get(course.disciplineId).add(slot.day);
  }
  const ranked=[];
  for(const [id,eligibleCourses] of grouped){
    const discipline=disciplines.get(id), features=discipline.features || {};
    const configuredGoals=new Set((Array.isArray(features.goals)?features.goals:[]).filter(value=>typeof value==='string').map(normalize));
    const configuredPreferences=new Set(Array.isArray(features.preferences)?features.preferences:[]);
    const matchedGoals=config.goals.filter(row=>answers.goals.includes(row.id) && (configuredGoals.has(normalize(row.id)) || configuredGoals.has(normalize(row.label))));
    const matchedPreferences=config.preferences.filter(row=>answers.preferences.includes(row.id) && configuredPreferences.has(row.id));
    const matchedDays=answers.days.filter(day=>availableDays.get(id)?.has(day)).sort((a,b)=>a-b);
    const points={goals:matchedGoals.length*config.weights.goal,preferences:matchedPreferences.length*config.weights.preference,days:matchedDays.length*config.weights.day};
    ranked.push({discipline,courseIds:eligibleCourses.map(row=>row.id).sort((a,b)=>a-b),matchedGoals,matchedPreferences,matchedDays,availableDays:[...(availableDays.get(id)||[])].sort((a,b)=>a-b),points,score:points.goals+points.preferences+points.days});
  }
  ranked.sort((a,b)=>b.score-a.score || (Number.isInteger(a.discipline.order)?a.discipline.order:0)-(Number.isInteger(b.discipline.order)?b.discipline.order:0) || a.discipline.id-b.discipline.id);
  const main=ranked.filter(row=>row.score>0).slice(0,3);const selected=new Set(main.map(row=>row.discipline.id));
  return {main,alternatives:ranked.filter(row=>!selected.has(row.discipline.id)).slice(0,3),eligibleCount:ranked.length};
}
