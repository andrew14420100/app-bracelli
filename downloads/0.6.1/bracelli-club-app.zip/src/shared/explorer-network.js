import {validateSettings} from './explorer-engine.js';
/** GET-only loader: answers are deliberately not arguments of this function. */
export async function fetchExplorerSnapshot(endpoint, {signal, validate=value=>value, credentials='omit'}={}) {
  if(!['omit','same-origin'].includes(credentials))throw Error('Credenziali non consentite');
  if (navigator.onLine===false) throw Error('Offline');
  const url=new URL(endpoint,location.href);
  if(url.origin!==location.origin)throw Error('Origin non consentito');
  const controller=new AbortController();const abort=()=>controller.abort();signal?.addEventListener('abort',abort,{once:true});
  if(signal?.aborted)controller.abort();const timer=setTimeout(abort,8000);
  try{
    const response=await fetch(url,{method:'GET',credentials,cache:'no-store',signal:controller.signal,headers:{Accept:'application/json'}});
    if(!response.ok || Number(response.headers.get('Age'))>0)throw Error('Dati aggiornati non disponibili');
    const snapshot=validate(await response.json());validateSettings(snapshot.explorer);
    if(!['disciplines','courses','instructors','schedule'].every(key=>Array.isArray(snapshot[key])))throw Error('Catalogo non valido');
    return snapshot;
  }finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}
}
