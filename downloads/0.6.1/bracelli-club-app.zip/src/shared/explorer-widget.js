import {recommend,validateSettings} from './explorer-engine.js';
const days=['Lunedì','Martedì','Mercoledì','Giovedì','Venerdì','Sabato','Domenica'];
const questions=['Per chi cerchi un’attività?','Quanti anni ha chi parteciperà?','Quali sono gli obiettivi?','Quali attività preferisci?','Quali giorni preferisci?'];
const node=(tag,text,className)=>{const item=document.createElement(tag);if(text!==undefined)item.textContent=text;if(className)item.className=className;return item;};
const button=(label,handler,className='')=>{const item=node('button',label,className);item.type='button';item.onclick=handler;return item;};
export function mountExplorer(root,{loadSnapshot,preview=false,expiryMs=60000}={}) {
  if(!root || typeof loadSnapshot!=='function')throw Error('Explorer non configurato');
  root.classList.add('explorer-widget');
  let step=0,phase='intro',settings,snapshot,answers,anyDays=false,generation=0,request,timer;
  const prefix=root.id || 'explorer';
  const freshAnswers=()=>({recipient:'',age:'',goals:[],preferences:[],days:[]});answers=freshAnswers();
  function stop(){generation++;request?.abort();clearTimeout(timer);}
  function reset(){stop();step=0;phase='intro';answers=freshAnswers();anyDays=false;snapshot=null;intro();}
  function title(text){const heading=node('h3',text);heading.tabIndex=-1;root.append(heading);return heading;}
  function focus(item){item.focus({preventScroll:true});}
  function clear(){root.replaceChildren();clearTimeout(timer);}
  function privacy(){root.append(node('p','Le risposte restano solo in questa pagina e non vengono salvate. Nessun nome, contatto o registrazione.','quiz-note'));}
  function intro(message=''){
    clear();const heading=title('Trova il tuo sport');root.append(node('p','Cinque passaggi per esplorare le attività configurate dal club.'));
    if(message){const error=node('p',message,'quiz-error');error.setAttribute('role','alert');root.append(error);}
    root.append(button(message?'Riprova ad avviare':'Inizia il percorso',start));privacy();if(message)focus(heading);
  }
  async function getSnapshot(){request?.abort();request=new AbortController();const value=await loadSnapshot({signal:request.signal});validateSettings(value.explorer);return value;}
  async function start(){
    stop();const token=generation;phase='loading';clear();const loading=node('p','Caricamento del catalogo aggiornato…');loading.setAttribute('role','status');root.append(loading);
    try{const value=await getSnapshot();if(token!==generation)return;snapshot=value;settings=value.explorer;phase='quiz';renderStep();}
    catch{if(token!==generation)return;phase='intro';intro('Il catalogo aggiornato non è disponibile. Controlla la connessione e riprova.');}
  }
  function choices(fieldset,name,rows,multiple,selected,exclusive=''){
    for(const row of rows){
      const label=node('label',undefined,'quiz-choice'),input=node('input');input.type=multiple?'checkbox':'radio';input.name=name;input.value=String(row.id);input.checked=selected.includes(String(row.id));
      if(multiple && exclusive)input.onchange=()=>{if(input.checked){for(const other of fieldset.querySelectorAll(`input[name="${name}"]`)){if(other!==input && (input.value===exclusive || other.value===exclusive))other.checked=false;}}};
      label.append(input,node('span',row.label));fieldset.append(label);
    }
  }
  function read(form){
    const selected=name=>[...form.querySelectorAll(`input[name="${name}"]:checked`)].map(item=>item.value);
    if(step===0)answers.recipient=selected('recipient')[0] || '';
    if(step===1)answers.age=form.elements.age.value;
    if(step===2)answers.goals=selected('goals');
    if(step===3)answers.preferences=selected('preferences');
    if(step===4){const value=selected('days');anyDays=value.includes('any');answers.days=value.filter(day=>day!=='any').map(Number);}
  }
  function errorForStep(){
    if(step===0 && !['self','child'].includes(answers.recipient))return 'Scegli per chi cerchi l’attività.';
    if(step===1 && (!/^\d{1,3}$/.test(answers.age) || Number(answers.age)>120))return 'Inserisci un’età intera tra 0 e 120 anni.';
    if(step===2 && !answers.goals.some(id=>settings.goals.some(row=>row.id===id)))return 'Seleziona almeno un obiettivo.';
    if(step===3 && !answers.preferences.some(id=>id==='none'||settings.preferences.some(row=>row.id===id)))return 'Seleziona una preferenza oppure Nessuna preferenza.';
    if(step===4 && !anyDays && !answers.days.length)return 'Seleziona almeno un giorno oppure Nessuna preferenza di giorno.';
    return '';
  }
  function renderStep(){
    phase='quiz';clear();
    const status=node('p',`Passaggio ${step+1} di 5`,'eyebrow');status.setAttribute('role','status');root.append(status);
    const progress=node('progress');progress.max=5;progress.value=step+1;progress.setAttribute('aria-label','Avanzamento questionario');root.append(progress);
    const form=node('form');form.noValidate=true;
    const fieldset=node('fieldset');fieldset.tabIndex=-1;fieldset.append(node('legend',questions[step]));
    const error=node('p','','quiz-error');error.id=`${prefix}-error`;error.setAttribute('role','alert');fieldset.setAttribute('aria-describedby',error.id);
    if(step===0)choices(fieldset,'recipient',[{id:'self',label:'Per me'},{id:'child',label:'Per mio figlio / mia figlia'}],false,[answers.recipient]);
    if(step===1){const label=node('label','Età in anni compiuti','quiz-age');const input=node('input');input.type='number';input.name='age';input.min=0;input.max=120;input.step=1;input.inputMode='numeric';input.required=true;input.value=answers.age;label.append(input);fieldset.append(label,node('p','L’età viene confrontata solo con le fasce numeriche configurate nei corsi.','quiz-note'));}
    if(step===2)choices(fieldset,'goals',settings.goals,true,answers.goals);
    if(step===3)choices(fieldset,'preferences',[...settings.preferences,{id:'none',label:'Nessuna preferenza'}],true,answers.preferences,'none');
    if(step===4)choices(fieldset,'days',[...days.map((label,index)=>({id:index+1,label})),{id:'any',label:'Nessuna preferenza di giorno'}],true,anyDays?['any']:answers.days.map(String),'any');
    form.append(fieldset,error);
    const actions=node('div',undefined,'quiz-actions');
    if(step>0)actions.append(button('Indietro',()=>{read(form);step--;renderStep();},'secondary'));
    const next=node('button',step===4?'Mostra i risultati':'Avanti');next.type='submit';actions.append(next,button('Ricomincia',reset,'secondary'));form.append(actions);
    form.onsubmit=event=>{event.preventDefault();read(form);const message=errorForStep();if(message){error.textContent=message;fieldset.setAttribute('aria-invalid','true');focus(fieldset);return;}if(step<4){step++;renderStep();}else calculate();};
    root.append(form);privacy();focus(fieldset);
  }
  function edit(){stop();phase='quiz';step=0;renderStep();}
  function invalidate(message){
    stop();snapshot=null;phase='stale';clear();const heading=title('Aggiorna le raccomandazioni');root.append(node('p',message,'quiz-error'));
    root.append(button('Aggiorna risultati',calculate),button('Modifica risposte',edit,'secondary'),button('Ricomincia',reset,'secondary'));focus(heading);
  }
  async function calculate(){
    stop();const token=generation;phase='calculating';clear();const loading=node('p','Verifica del catalogo e degli orari aggiornati…');loading.setAttribute('role','status');root.append(loading);
    try{
      const value=await getSnapshot();if(token!==generation)return;
      snapshot=value;settings=value.explorer;
      const result=recommend(snapshot,{...answers,age:Number(answers.age)},settings);phase='results';renderResults(result);
    }catch(error){
      if(token!==generation)return;phase='stale';clear();const heading=title('Risultati non disponibili');
      root.append(node('p',error.message?.includes('opzioni')?'Le opzioni sono cambiate. Modifica le risposte o ricomincia.':'Non possiamo verificare il catalogo aggiornato. Controlla la connessione e riprova.','quiz-error'));
      root.append(button('Riprova risultati',calculate),button('Modifica risposte',edit,'secondary'),button('Ricomincia',reset,'secondary'));focus(heading);
    }
  }
  function media(url,name){
    try{const src=new URL(url,location.href);if(!url || src.origin!==location.origin || !['http:','https:'].includes(src.protocol) || src.username || src.password)return null;const image=node('img');image.src=src.href;image.alt=name;image.loading='lazy';image.decoding='async';image.width=640;image.height=400;return image;}catch{return null;}
  }
  function resultCard(row,alternative){
    const discipline=row.discipline,card=node('article',undefined,'quiz-result card');const image=media(discipline.photos?.[0],discipline.name);if(image)card.append(image);else card.append(node('p','Fotografia non ancora disponibile.','quiz-note'));
    card.append(node('h4',discipline.name),node('p',discipline.description || discipline.summary || ''));
    const reasons=node('ul');reasons.append(node('li',`Età compatibile con ${row.courseIds.length} ${row.courseIds.length===1?'corso pubblicato':'corsi pubblicati'}.`));
    if(row.matchedGoals.length)reasons.append(node('li',`Obiettivi configurati corrispondenti: ${row.matchedGoals.map(item=>item.label).join(', ')}.`));
    if(row.matchedPreferences.length)reasons.append(node('li',`Preferenze soddisfatte: ${row.matchedPreferences.map(item=>item.label).join(', ')}.`));
    if(row.matchedDays.length)reasons.append(node('li',`Giorni preferiti presenti nel calendario: ${row.matchedDays.map(day=>days[day-1]).join(', ')}.`));
    else if(answers.days.length)reasons.append(node('li','Nessun orario pubblicato nei giorni preferiti per i corsi compatibili con l’età.'));
    if(!row.availableDays.length)reasons.append(node('li','Orari pubblicati non disponibili per i corsi compatibili.'));
    else if(!answers.days.length)reasons.append(node('li',`Giorni nel calendario dei corsi compatibili: ${row.availableDays.map(day=>days[day-1]).join(', ')}.`));
    if(alternative && row.score===0)reasons.append(node('li','Alternativa compatibile per età, senza corrispondenze con punteggio alle preferenze indicate.'));
    card.append(reasons);
    if(preview)card.append(node('p',`Punti interni: ${row.score} (obiettivi ${row.points.goals}, preferenze ${row.points.preferences}, giorni ${row.points.days}). Non sono percentuali.`, 'quiz-note'));
    if(!preview){const detail=node('a','Scheda disciplina','text-link');detail.href=`#discipline/${discipline.id}`;card.append(detail);const courses=node('p','Corsi compatibili: ');
      for(const id of row.courseIds){const course=snapshot.courses.find(item=>item.id===id);const a=node('a',course.name,'text-link');a.href=`#course/${id}`;courses.append(a);}card.append(courses);
    }
    const trialCourses=row.courseIds.map(id=>snapshot.courses.find(course=>course.id===id)).filter(course=>course?.trial);
    const trial=button('Richiedi una prova',()=>{location.hash=`trial?discipline=${discipline.id}${trialCourses.length===1?'&course='+trialCourses[0].id:''}`;});
    trial.disabled=preview||!trialCourses.length;
    const note=node('p',preview?'La richiesta non viene inviata dalla simulazione amministrativa.':trialCourses.length?'La segreteria concorderà giorno e disponibilità dopo aver ricevuto la richiesta.':'Lezione di prova non indicata per i corsi compatibili.','quiz-note');
    note.id=`${prefix}-trial-${discipline.id}`;trial.setAttribute('aria-describedby',note.id);card.append(trial,note);
    return card;
  }
  function renderResults(result){
    clear();const heading=title('Il tuo percorso sportivo');
    if(snapshot.demonstration)root.append(node('p','DEMO: esempi dimostrativi, non attività reali del club.','demo-notice'));
    root.append(node('p','Suggerimenti basati sulle risposte e sui dati configurati dal club. Non sono una valutazione medica o di idoneità sportiva.','quiz-note'));
    root.append(node('p',`Catalogo verificato alle ${new Intl.DateTimeFormat('it-IT',{hour:'2-digit',minute:'2-digit'}).format(new Date())}. I giorni pubblicati non garantiscono posti disponibili. I risultati scadono dopo un minuto.`, 'quiz-note'));
    if(!result.main.length){const empty=node('p','Nessuna corrispondenza con le preferenze indicate. Puoi modificare le risposte o esplorare il catalogo.','empty');empty.setAttribute('role','status');root.append(empty);}
    else{root.append(node('h4','Discipline consigliate'));const cards=node('div',undefined,'quiz-results');for(const row of result.main)cards.append(resultCard(row,false));root.append(cards);}
    if(result.alternatives.length){const group=node('details');group.append(node('summary','Alternative compatibili per età'));const cards=node('div',undefined,'quiz-results');for(const row of result.alternatives)cards.append(resultCard(row,true));group.append(cards);root.append(group);}
    if(!result.eligibleCount)root.append(node('p','Non risultano corsi pubblici con una fascia d’età numerica compatibile. Puoi verificare l’età inserita o consultare le schede del catalogo.'));
    const actions=node('div',undefined,'quiz-actions');actions.append(button('Modifica risposte',edit,'secondary'),button('Aggiorna risultati',calculate),button('Ricomincia',reset,'secondary'));root.append(actions);privacy();focus(heading);
    timer=setTimeout(()=>invalidate('Per evitare di mostrare orari non più aggiornati, verifica nuovamente il catalogo.'),expiryMs);
  }
  const offline=()=>{if(phase==='results'||phase==='calculating')invalidate('Sei offline. Non mostriamo disponibilità non verificabili. Riconnettiti e aggiorna i risultati.');};
  const visibility=()=>{if(document.hidden && phase==='results')invalidate('La pagina è stata lasciata in sospeso: aggiorna il catalogo prima di usare i risultati.');};
  window.addEventListener('offline',offline);document.addEventListener('visibilitychange',visibility);intro();
  return ()=>{stop();window.removeEventListener('offline',offline);document.removeEventListener('visibilitychange',visibility);root.replaceChildren();};
}
