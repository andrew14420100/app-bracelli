export const days = ['Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato', 'Domenica'];
export const levels = {all:'Tutti i livelli', beginner:'Base', intermediate:'Intermedio', advanced:'Avanzato'};
const positive = value => Number.isSafeInteger(value) && value > 0;
const text = value => typeof value === 'string';
const strings = value => Array.isArray(value) && value.every(text);
const base = item => item && positive(item.id) && text(item.name) && text(item.description) && text(item.summary);
const clock = value => text(value) && /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value);
export function validateCatalog(data) {
  if (!data || !['disciplines','courses','instructors','schedule'].every(key => Array.isArray(data[key])) || !text(data.timezone)) throw Error('Catalogo non valido');
  const unique = items => new Set(items.map(item => item.id)).size === items.length;
  if (!data.disciplines.every(item => base(item) && strings(item.categories) && strings(item.ages) && strings(item.benefits) && strings(item.photos) && text(item.video) && item.features && strings(item.features.goals)) ||
      !data.instructors.every(item => base(item) && text(item.photo)) ||
      !data.courses.every(item => base(item) && positive(item.disciplineId) && Array.isArray(item.instructorIds) && item.instructorIds.every(positive) && text(item.age) && Object.hasOwn(levels,item.level) && text(item.room) && typeof item.trial === 'boolean') ||
      !data.schedule.every(item => item && positive(item.id) && positive(item.courseId) && positive(item.instructorId) && Number.isInteger(item.day) && item.day >= 1 && item.day <= 7 && clock(item.start) && clock(item.end) && item.end > item.start && text(item.room)) ||
      !['disciplines','courses','instructors','schedule'].every(key => unique(data[key]))) throw Error('Dati catalogo non validi');
  const disciplineIds = new Set(data.disciplines.map(item => item.id));
  const instructorIds = new Set(data.instructors.map(item => item.id));
  if (data.courses.some(item => !disciplineIds.has(item.disciplineId) || item.instructorIds.some(id => !instructorIds.has(id)))) throw Error('Collegamenti corsi non validi');
  const courses = new Map(data.courses.map(item => [item.id,item]));
  if (data.schedule.some(item => !courses.has(item.courseId) || !courses.get(item.courseId).instructorIds.includes(item.instructorId))) throw Error('Collegamenti orari non validi');
  return {...data, schedule:[...data.schedule].sort((a,b) => a.day-b.day || a.start.localeCompare(b.start) || a.id-b.id)};
}
const normalize = value => String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('it');
export function filterDisciplines(data, {query='',category='',age='',level='',trial=false} = {}) {
  return data.disciplines.filter(item => {
    const courses = data.courses.filter(course => course.disciplineId === item.id);
    const matchingCourses = courses.filter(course => (!age || course.age === age || item.ages.includes(age)) && (!level || course.level === level) && (!trial || course.trial));
    return (!query || normalize([item.name,item.description,item.summary,...item.categories,...item.benefits,...courses.map(course=>course.name)].join(' ')).includes(normalize(query.trim()))) &&
      (!category || item.categories.includes(category)) &&
      (!(age || level || trial) || matchingCourses.length > 0 || (!level && !trial && item.ages.includes(age)));
  });
}
export function filterSchedule(data, {day='',discipline='',course='',instructor=''} = {}) {
  const courses = new Map(data.courses.map(item => [item.id,item]));
  return data.schedule.filter(slot => (!day || slot.day === Number(day)) && (!course || slot.courseId === Number(course)) && (!instructor || slot.instructorId === Number(instructor)) && (!discipline || courses.get(slot.courseId)?.disciplineId === Number(discipline)));
}
export function safeMedia(value, origin) {
  try {const url=new URL(value,origin);return value && ['http:','https:'].includes(url.protocol) && url.origin===new URL(origin).origin && !url.username && !url.password ? url.href : ''; } catch {return '';}
}
