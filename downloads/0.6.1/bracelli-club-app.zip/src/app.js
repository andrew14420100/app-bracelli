import './ui-shell.js';
import './pwa.js';
import './identity.js';
import './trial-ui.js';
import './explorer.js';
import {startCatalog} from './catalog-ui.js';
import {config} from './config.js';
import {validateFeed, renderItems} from './content.js';
async function load() {
  const status = document.querySelector('#content-status');
  const retry = document.querySelector('#content-retry');
  retry.hidden = true;
  let feed = {news:[], events:[]};
  status.setAttribute('aria-busy', 'true');
  try {
    const response = await fetch(`${config.apiBase}/home`, {signal:AbortSignal.timeout(8000),credentials:config.credentials});
    if (!response.ok) throw new Error('Feed non disponibile');
    feed = validateFeed(await response.json());status.textContent = 'Aggiornamenti dal club';
  } catch {
    status.textContent = navigator.onLine ? 'Contenuti non disponibili. Riprova più tardi.' : 'Sei offline. I contenuti aggiornati richiedono una connessione.';
    retry.hidden = false;
  } finally {status.removeAttribute('aria-busy');}
  renderItems(document.querySelector('#news-list'), feed.news, 'Le novità del club appariranno qui.');
  renderItems(document.querySelector('#events-list'), feed.events, 'Nessun appuntamento da mostrare. Torna a trovarci.');
}
document.querySelector('#content-retry').addEventListener('click', load);
load();
startCatalog();
