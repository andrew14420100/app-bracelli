export function validateFeed(value) {
  if (!value || !Array.isArray(value.news) || !Array.isArray(value.events)) throw new Error('Feed non valido');
  return { news: value.news.filter(validItem), events: value.events.filter(validItem) };
}
function validItem(item) { return item && typeof item.title === 'string' && typeof item.excerpt === 'string' && typeof item.date === 'string'; }
export function renderItems(container, items, emptyText) {
  container.replaceChildren();
  if (!items.length) { const p = document.createElement('p'); p.className = 'empty'; p.textContent = emptyText; container.append(p); return; }
  for (const item of items) {
    const card = document.createElement('article'); card.className = 'card';
    const date = document.createElement('time'); const parsed = new Date(item.date);
    if (!Number.isNaN(parsed.getTime())) { date.dateTime = item.date; date.textContent = 'Pubblicato il ' + new Intl.DateTimeFormat('it-IT', {dateStyle:'long'}).format(parsed); }
    const title = document.createElement('h3'); title.textContent = item.title;
    const excerpt = document.createElement('p'); excerpt.textContent = item.excerpt;
    card.append(date, title, excerpt); container.append(card);
  }
}
