// Same-origin defaults; the bundled WordPress entry supplies its own REST base.
const meta = name => typeof document === 'undefined' ? '' : document.querySelector(`meta[name="${name}"]`)?.content || '';
export const config = Object.freeze({apiBase:meta('bracelli-api-base') || '/wp-json/bracelli-club/v1',credentials:meta('bracelli-api-credentials') === 'same-origin' ? 'same-origin' : 'omit'});
