import {config} from './config.js';
import {validateCatalog,filterDisciplines,filterSchedule,days,levels,safeMedia} from './catalog-data.js';
const el = (tag,text,className) => {const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(className)node.className=className;return node;};
const link = (text,href) => {const node=el('a',text,'text-link');node.href=href;return node;};
function photo(url, name) {const src=safeMedia(url,location.origin);if(!src)return null;const image=el('img');image.src=src;image.alt=name;image.loading='lazy';image.decoding='async';image.width=640;image.height=400;image.className='catalog-photo';return image;}
function appendPhoto(parent,url,name) {const image=photo(url,name);if(image)parent.append(image);}
const empty = (container,text) => container.append(el('p',text,'empty'));
function options(select, values, placeholder) {
  select.replaceChildren(new Option(placeholder,''));
  for(const [value,label] of values)select.add(new Option(label,String(value)));
}
function uniqueOptions(values) {return [...new Set(values)].sort((a,b)=>a.localeCompare(b,'it')).map(value=>[value,value]);}
function courseCard(course,data) {
  const card=el('article',undefined,'card');card.append(link(course.name,`#course/${course.id}`),el('p',course.summary || course.description));
  card.append(el('p',[course.age,levels[course.level],course.room].filter(Boolean).join(' · ')));
  card.append(el('p',navigator.onLine===false?'Offline · Indicazioni sulla prova da verificare online':course.trial?'Lezione di prova disponibile':'Lezione di prova non indicata','trial-availability'));
  for(const id of course.instructorIds){const instructor=data.instructors.find(item=>item.id===id);card.append(link(instructor.name,`#instructor/${id}`));}
  if(course.trial)card.append(link('Richiedi una prova',`#trial?discipline=${course.disciplineId}&course=${course.id}`));
  card.append(link('Vedi gli orari',`#schedule?course=${course.id}`));return card;
}
let requestVersion=0;
let currentRoute;
window.addEventListener('bracelli:catalog-snapshot',event=>startCatalog(event.detail));
export async function startCatalog(snapshot) {
  const version=++requestVersion;
  document.querySelector('#catalog-status').setAttribute('aria-busy','true');
  const preserved=new Map([...document.querySelectorAll('#catalog-filters select, #schedule-filters select')].map(select=>[select.id,select.value]));
  const status=document.querySelector('#catalog-status');let data;
  const retry=document.querySelector('#catalog-retry');retry.hidden=true;
  try {
    if(snapshot) data=validateCatalog(snapshot);
    else {
      const response=await fetch(`${config.apiBase}/catalog`,{credentials:config.credentials,signal:AbortSignal.timeout(8000),cache:'no-store'});
      if(!response.ok||Number(response.headers.get('Age'))>0)throw Error('Catalogo non disponibile');data=validateCatalog(await response.json());
    }
    if(version!==requestVersion)return;
  }catch{
    if(version!==requestVersion)return;
    status.removeAttribute('aria-busy');
    status.textContent=navigator.onLine?'Catalogo e calendario non disponibili. Riprova più tardi.':'Sei offline. Catalogo e orari aggiornati richiedono una connessione.';
    document.querySelector('#schedule-status').textContent='Gli orari non sono disponibili.';
    document.querySelector('#instructor-status').textContent='Le presentazioni non sono disponibili. Riprova a caricare il catalogo.';retry.hidden=false;retry.onclick=()=>startCatalog();return;
  }
  if(data.demonstration === true) {const notice=document.querySelector('#demo-notice');notice.textContent='Modalità dimostrativa: dati di esempio, non offerta reale del Bracelli Club.';notice.classList.add('demo-notice');}
  status.removeAttribute('aria-busy');
  status.textContent=data.disciplines.length ? `${data.disciplines.length} discipline pubblicate` : 'Non ci sono ancora discipline pubblicate.';
  document.querySelector('#catalog-filters').hidden=false;document.querySelector('#schedule-filters').hidden=false;
  document.querySelector('#schedule-status').textContent=`Settimana tipo · Orari locali del club (${data.timezone || 'fuso orario WordPress'}). Le sospensioni non sono mostrate.`;
  const courseById=new Map(data.courses.map(item=>[item.id,item]));
  const instructorById=new Map(data.instructors.map(item=>[item.id,item]));
  const category=document.querySelector('#filter-category'),age=document.querySelector('#filter-age'),level=document.querySelector('#filter-level');
  options(category,uniqueOptions(data.disciplines.flatMap(item=>item.categories)),'Tutte le categorie');
  options(age,uniqueOptions([...data.disciplines.flatMap(item=>item.ages),...data.courses.map(item=>item.age)].filter(Boolean)),'Tutte le fasce d’età');
  options(level,Object.entries(levels),'Qualsiasi livello');
  options(document.querySelector('#schedule-day'),days.map((name,index)=>[index+1,name]),'Tutti i giorni');
  options(document.querySelector('#schedule-discipline'),data.disciplines.map(item=>[item.id,item.name]),'Tutte le discipline');
  options(document.querySelector('#schedule-course'),data.courses.map(item=>[item.id,item.name]),'Tutti i corsi');
  options(document.querySelector('#schedule-instructor'),data.instructors.map(item=>[item.id,item.name]),'Tutti gli istruttori');
  for(const [id,value] of preserved){const select=document.getElementById(id);if([...select.options].some(option=>option.value===value))select.value=value;}
  function renderCatalog() {
    const container=document.querySelector('#discipline-list');container.replaceChildren();
    const items=filterDisciplines(data,{query:document.querySelector('#filter-search').value,category:category.value,age:age.value,level:level.value,trial:document.querySelector('#filter-trial').checked});
    document.querySelector('#catalog-count').textContent=`${items.length} risultati`;
    const fragment=document.createDocumentFragment();
    for(const item of items){const card=el('article',undefined,'card discipline-card');appendPhoto(card,item.photos[0],item.name);card.append(el('p',item.categories.join(' · '),'eyebrow'),el('h3',item.name),el('p',item.summary || item.description),link('Scopri disciplina e corsi',`#discipline/${item.id}`));fragment.append(card);}
    container.append(fragment);
    if(!items.length)empty(container,'Nessuna disciplina corrisponde ai filtri selezionati.');
  }
  function renderSchedule() {
    const container=document.querySelector('#schedule-list');container.replaceChildren();
    const slots=filterSchedule(data,{day:document.querySelector('#schedule-day').value,discipline:document.querySelector('#schedule-discipline').value,course:document.querySelector('#schedule-course').value,instructor:document.querySelector('#schedule-instructor').value});
    document.querySelector('#schedule-count').textContent=`${slots.length} orari`;
    for(let day=1;day<=7;day++){
      const items=slots.filter(item=>item.day===day);if(!items.length)continue;
      const section=el('section',undefined,'schedule-day');section.append(el('h3',days[day-1]));
      for(const slot of items){const course=courseById.get(slot.courseId),instructor=instructorById.get(slot.instructorId);const card=el('article',undefined,'slot');card.append(el('p',`${slot.start} – ${slot.end}`,'slot-time'),link(course.name,`#course/${course.id}`),el('p',slot.room || 'Sala non indicata'),link(instructor.name,`#instructor/${instructor.id}`));section.append(card);}
      container.append(section);
    }
    if(!slots.length)empty(container,'Nessun orario disponibile per i filtri selezionati.');
  }
  document.querySelector('#catalog-filters').oninput=renderCatalog;
  document.querySelector('#catalog-filters').onreset=()=>setTimeout(renderCatalog,0);
  document.querySelector('#schedule-filters').onchange=renderSchedule;
  document.querySelector('#schedule-filters').onreset=()=>setTimeout(renderSchedule,0);
  for(const form of document.querySelectorAll('.catalog-filters'))form.onsubmit=event=>event.preventDefault();
  document.querySelector('#instructor-status').textContent='Schede pubblicate dal club';
  const instructors=document.querySelector('#instructor-list');instructors.replaceChildren();
  for(const item of data.instructors){const card=el('article',undefined,'card');appendPhoto(card,item.photo,item.name);card.append(el('h3',item.name),el('p',item.summary || item.description),link('Presentazione e corsi',`#instructor/${item.id}`));instructors.append(card);}
  if(!data.instructors.length)empty(instructors,'Le presentazioni degli istruttori saranno disponibili qui.');
  function route() {
    const hash=location.hash.slice(1);const detail=document.querySelector('#catalog-detail');
    if(hash.startsWith('schedule?')) {
      const id=new URLSearchParams(hash.split('?')[1]).get('course');
      document.querySelector('#schedule-filters').reset();
      document.querySelector('#schedule-course').value=data.courses.some(item=>String(item.id)===id)?id:'';renderSchedule();
      document.querySelector('#schedule').scrollIntoView();
    }
    const match=/^(discipline|course|instructor)\/(\d+)$/.exec(hash);
    detail.hidden=!match;if(!match)return;
    detail.replaceChildren();detail.append(link('← Catalogo discipline','#disciplines'));
    const collection={discipline:data.disciplines,course:data.courses,instructor:data.instructors}[match[1]];
    const item=collection.find(entry=>entry.id===Number(match[2]));
    if(!item){detail.append(el('h2','Contenuto non disponibile'),el('p','Il contenuto potrebbe non essere più pubblicato.'));}
    else {
      detail.append(el('p',{discipline:'DISCIPLINA',course:'CORSO',instructor:'ISTRUTTORE'}[match[1]],'eyebrow'),el('h2',item.name),el('p',item.description,'description'));
      if(match[1]==='discipline') {
        const gallery=el('div',undefined,'gallery');for(const url of item.photos)appendPhoto(gallery,url,item.name);detail.append(gallery);
        const src=safeMedia(item.video,location.origin);if(src){const video=el('video');video.src=src;video.controls=true;video.preload='metadata';video.setAttribute('aria-label',`Video ${item.name}`);detail.append(video);}
        detail.append(el('p',item.categories.join(' · ')),el('p',`Fasce d’età: ${item.ages.join(', ') || 'Non indicate'}`),el('h3','Benefici'));
        const benefits=el('ul');for(const benefit of item.benefits)benefits.append(el('li',benefit));detail.append(benefits);
      }
      let courses;
      if(match[1]==='course'){
        const discipline=data.disciplines.find(entry=>entry.id===item.disciplineId);detail.append(link(`Disciplina: ${discipline.name}`,`#discipline/${discipline.id}`));courses=[item];
      }else{if(match[1]==='instructor')appendPhoto(detail,item.photo,item.name);courses=data.courses.filter(course=>match[1]==='discipline'?course.disciplineId===item.id:course.instructorIds.includes(item.id));}
      detail.append(el('h3',match[1]==='course'?'Informazioni e collegamenti':'Corsi disponibili'));
      const cards=el('div',undefined,'cards');for(const course of courses)cards.append(courseCard(course,data));if(!courses.length)empty(cards,'Nessun corso attualmente disponibile.');detail.append(cards);
    }
    detail.scrollIntoView();detail.focus({preventScroll:true});
  }
  renderCatalog();renderSchedule();
  if(currentRoute)window.removeEventListener('hashchange',currentRoute);
  currentRoute=route;window.addEventListener('hashchange',route);route();
}

window.addEventListener('offline',()=>{for(const label of document.querySelectorAll('.trial-availability'))label.textContent='Offline · Indicazioni sulla prova da verificare online';document.querySelector('#schedule-status').textContent='Offline · Gli orari già visualizzati possono non essere aggiornati. Nessuna disponibilità è verificata.';document.querySelector('#catalog-status').textContent='Offline · Catalogo già visualizzato, da verificare online.';});
window.addEventListener('online',()=>{document.querySelector('#catalog-retry').hidden=false;document.querySelector('#catalog-retry').onclick=()=>startCatalog();document.querySelector('#schedule-status').textContent='Connessione ripristinata. Ricarica il catalogo per verificare gli orari aggiornati.';});
