const banner = document.querySelector('#update-banner');
let registration, updating = false, busy = false;
window.addEventListener('bracelli:trial-busy', event => {busy = event.detail === true;});
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('./sw.js', {updateViaCache: 'none'}).then(value => {
    registration = value;
    const show = () => {if (registration.waiting && navigator.serviceWorker.controller) banner.hidden = false;};
    show();
    registration.addEventListener('updatefound', () => {
      registration.installing?.addEventListener('statechange', show);
    });
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) registration.update().catch(() => {});
    });
  }).catch(() => {/* Online functionality does not depend on service worker support. */});
  navigator.serviceWorker.addEventListener('controllerchange', () => {if (updating) location.reload();});
  navigator.serviceWorker.addEventListener('message', event => {
    if (event.data?.type === 'BC_UPDATE_BLOCKED') {
      updating = false;
      banner.querySelector('span').textContent = 'Chiudi le altre schede Bracelli Club, poi premi Aggiorna app. Le richieste aperte nelle altre schede non vengono interrotte.';
    }
  });
}
document.querySelector('#apply-update').addEventListener('click', () => {
  if (!registration?.waiting) return;
  if (busy) {banner.querySelector('span').textContent = 'Attendi l’esito dell’invio prima di aggiornare.';return;}
  const form = document.querySelector('.trial-form');
  const dirty = form && [...form.querySelectorAll('input:not([type=hidden]),textarea')].some(input => input.type === 'checkbox' ? input.checked : input.value.trim());
  if (dirty && !window.confirm('L’aggiornamento ricarica la pagina. I dati della richiesta non inviata andranno persi. Vuoi continuare?')) return;
  updating = true;
  registration.waiting.postMessage({type:'BC_APPLY_UPDATE'});
});
document.querySelector('#dismiss-update').addEventListener('click', () => {banner.hidden = true;});
let installPrompt;
const install = document.querySelector('#install');
window.addEventListener('beforeinstallprompt', event => {event.preventDefault();installPrompt = event;install.hidden = false;});
install.addEventListener('click', async () => {
  if (!installPrompt) return;
  await installPrompt.prompt();installPrompt = null;install.hidden = true;
});
window.addEventListener('appinstalled', () => {install.hidden = true;});
