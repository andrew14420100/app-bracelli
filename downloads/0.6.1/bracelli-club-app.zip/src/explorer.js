import {config} from './config.js';
import {validateCatalog} from './catalog-data.js';
import {mountExplorer} from './shared/explorer-widget.js';
import {fetchExplorerSnapshot} from './shared/explorer-network.js';
const root=document.querySelector('#explorer-panel');
if(root)mountExplorer(root,{loadSnapshot:async ({signal})=>{
  const snapshot=await fetchExplorerSnapshot(`${config.apiBase}/catalog`,{signal,validate:validateCatalog,credentials:config.credentials});
  window.dispatchEvent(new CustomEvent('bracelli:catalog-snapshot',{detail:snapshot}));
  return snapshot;
}});
