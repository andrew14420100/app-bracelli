<?php
// Runtime entry packaged in the plugin. Standard WordPress installation, no CLI.
$directory = __DIR__;
for ($attempt = 0; $attempt < 9 && !is_file($directory . '/wp-load.php'); $attempt++) {
    $parent = dirname($directory);
    if ($parent === $directory) { break; }
    $directory = $parent;
}
if (!is_file($directory . '/wp-load.php')) {
    http_response_code(503); header('Content-Type: text/plain; charset=UTF-8');
    exit('Installazione WordPress non trovata. Usare una struttura WordPress standard.');
}
define('WP_USE_THEMES', false);
require_once $directory . '/wp-load.php';
if (!function_exists('bracelli_app_api_base')) {
    http_response_code(503); header('Content-Type: text/plain; charset=UTF-8');
    exit('Attivare il plugin Bracelli Club nella bacheca WordPress.');
}
header('Content-Type: text/html; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, max-age=0');
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; media-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'");
if (!get_option('blog_public')) { header('X-Robots-Tag: noindex, nofollow, noarchive'); }
$bracelli_api_base = bracelli_app_api_base();
define('BRACELLI_APP_RENDER', true);
require __DIR__ . '/shell.php';
