<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
// Preserve editorial content on uninstall. No destructive automatic cleanup.

// Personal trial data is deleted on deliberate uninstall; editorial content is preserved.
global $wpdb;
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}bc_trial_requests");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}bc_trial_limits");
delete_option('bc_trial_settings');
delete_option('bc_trial_schema_version');
wp_clear_scheduled_hook('bc_trial_cleanup');
foreach(wp_roles()->roles as $role=>$definition){$object=get_role($role);if($object){$object->remove_cap('manage_bracelli_trials');}}

foreach(array('bc_admin_version','bc_rooms_migrated','bc_admin_audit','bc_identity_settings','bc_mail_diagnostic') as $option){delete_option($option);}
foreach(wp_roles()->roles as $name=>$definition){$role=get_role($name);foreach(array('bracelli_access','bracelli_view_trials','bracelli_edit_trials','bracelli_manage_content','bracelli_export_trials','bracelli_manage_settings','bracelli_delete_data','bracelli_override_schedule') as $cap){$role->remove_cap($cap);}}
remove_role('bracelli_secretary');

delete_option('bc_app_mail_capture');
delete_option('bc_app_mail_log');
