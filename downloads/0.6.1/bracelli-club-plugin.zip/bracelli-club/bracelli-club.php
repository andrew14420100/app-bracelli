<?php
/**
 * Plugin Name: Bracelli Club
 * Description: Contenuti indipendenti e API pubbliche per la PWA Bracelli Club.
 * Version: 0.6.1
 * Requires at least: 6.5
 * Requires PHP: 8.1
 * Text Domain: bracelli-club
 */
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/includes/admin-access.php';
require_once __DIR__ . '/includes/admin-rooms.php';
require_once __DIR__ . '/includes/content.php';
require_once __DIR__ . '/includes/rest.php';
add_action('init', 'bracelli_club_register_content');
add_action('rest_api_init', 'bracelli_club_register_routes');

require_once __DIR__ . '/includes/catalog-model.php';
require_once __DIR__ . '/includes/catalog-admin.php';
require_once __DIR__ . '/includes/catalog-rest.php';
add_action('init', 'bracelli_club_register_catalog');
add_action('rest_api_init', 'bracelli_club_register_catalog_routes');
add_action('admin_menu', 'bracelli_club_admin_menu');
add_action('add_meta_boxes', 'bracelli_club_add_boxes');
add_action('admin_enqueue_scripts', 'bracelli_club_admin_assets');
add_action('save_post', 'bracelli_club_save_catalog', 10, 2);
add_action('admin_notices', 'bracelli_club_admin_notice');
add_action('before_delete_post', 'bracelli_club_before_delete', 10, 2);
add_filter('manage_bc_slot_posts_columns', 'bracelli_club_slot_columns');
add_action('manage_bc_slot_posts_custom_column', 'bracelli_club_slot_column', 10, 2);
add_action('restrict_manage_posts', 'bracelli_club_slot_filters');
add_action('pre_get_posts', 'bracelli_club_filter_slots');

require_once __DIR__ . '/includes/explorer.php';
add_action('admin_menu', 'bracelli_club_explorer_menu');
add_action('admin_post_bc_explorer_settings', 'bracelli_club_explorer_save_settings');
add_action('admin_enqueue_scripts', 'bracelli_club_explorer_assets');
add_filter('script_loader_tag', 'bracelli_club_explorer_module_tag', 10, 2);

require_once __DIR__ . '/includes/trial-settings.php';
require_once __DIR__ . '/includes/trial-storage.php';
require_once __DIR__ . '/includes/trial-rest.php';
require_once __DIR__ . '/includes/trial-admin.php';
require_once __DIR__ . '/includes/trial-privacy.php';
register_activation_hook(__FILE__, 'bracelli_trial_install');
register_deactivation_hook(__FILE__, 'bracelli_trial_deactivate');
add_action('admin_init', 'bracelli_trial_upgrade');
add_action('bc_trial_cleanup', 'bracelli_trial_cleanup');
add_action('rest_api_init', 'bracelli_trial_routes');
add_action('admin_menu', 'bracelli_trial_menu');
add_action('admin_post_bc_trial_settings', 'bracelli_trial_save_settings_handler');
add_action('admin_post_bc_trial_update', 'bracelli_trial_update_handler');
add_filter('wp_privacy_personal_data_exporters', 'bracelli_trial_exporters');
add_filter('wp_privacy_personal_data_erasers', 'bracelli_trial_erasers');
add_filter('rest_post_dispatch', 'bracelli_trial_response_headers', 10, 3);

register_activation_hook(__FILE__, 'bracelli_admin_install');
add_action('admin_init', 'bracelli_admin_upgrade');
add_action('init', 'bracelli_rooms_register');
add_action('delete_term', 'bracelli_room_deleted', 10, 5);
add_action('admin_post_bc_permissions', 'bracelli_permissions_handler');
add_action('bc_trial_cleanup', 'bracelli_admin_audit_cleanup');

require_once __DIR__ . '/includes/admin-trials.php';
require_once __DIR__ . '/includes/admin-console.php';
add_action('admin_menu', 'bracelli_admin_menu_extra');
add_filter('admin_body_class', 'bracelli_admin_body');
add_action('admin_enqueue_scripts', 'bracelli_admin_assets');
add_action('all_admin_notices', 'bracelli_admin_navigation', 1);
add_action('admin_post_bc_trial_export', 'bracelli_trial_export_handler');
add_action('admin_post_bc_trials_bulk', 'bracelli_trial_bulk_handler');
add_action('admin_post_bc_identity', 'bracelli_identity_handler');
add_action('admin_post_bc_mail_test', 'bracelli_mail_test_handler');
add_action('rest_api_init', function(){register_rest_route('bracelli-club/v1','/identity',array('methods'=>WP_REST_Server::READABLE,'permission_callback'=>'__return_true','callback'=>'bracelli_identity_public'));});
add_action('restrict_manage_posts', 'bracelli_content_filter_ui');
add_action('pre_get_posts', 'bracelli_content_filter_query');
add_filter('redirect_post_location', 'bracelli_schedule_redirect', 10, 2);
add_filter('manage_bc_slot_posts_columns', 'bracelli_schedule_columns');
add_action('manage_bc_slot_posts_custom_column', 'bracelli_schedule_column', 10, 2);
add_action('all_admin_notices', 'bracelli_admin_flash_notice', 5);

add_action('admin_post_bc_trial_quick', 'bracelli_trial_quick_handler');

require_once __DIR__ . '/includes/app-distribution.php';
add_action('admin_menu', 'bracelli_app_menu');
