import {mountExplorer} from './explorer-widget.js';
import {fetchExplorerSnapshot} from './explorer-network.js';
const root=document.querySelector('#bc-explorer-preview');
if(root)mountExplorer(root,{preview:true,loadSnapshot:({signal})=>fetchExplorerSnapshot(root.dataset.api,{signal,credentials:'same-origin'})});
