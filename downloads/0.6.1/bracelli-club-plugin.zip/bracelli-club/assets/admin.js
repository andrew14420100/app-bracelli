/* global jQuery, wp */
jQuery(function ($) {
  $('.bc-clear-media').on('click',function(){document.getElementById($(this).data('input')).value='';});
  $('.bc-media').on('click', function () {
    const button = $(this);
    const picker = wp.media({title:'Media Bracelli Club',library:{type:button.data('media')},multiple:button.attr('data-multiple') === '1'});
    picker.on('select', function () { document.getElementById(button.data('input')).value = picker.state().get('selection').map(item => item.id).join(','); });
    picker.open();
  });
});
