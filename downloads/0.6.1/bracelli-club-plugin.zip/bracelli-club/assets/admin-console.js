// Loaded only on Bracelli screens; no requests or visitor tracking.
document.addEventListener('DOMContentLoaded',()=>{
 const body=document.querySelector('body.bc-admin-scope');if(!body)return;
 for(const form of body.querySelectorAll('form')){
  const counter=form.querySelector('.bc-selection-count');if(!counter)continue;
  form.addEventListener('change',()=>{counter.textContent=`${form.querySelectorAll('input[name="ids[]"]:checked').length} richieste selezionate`;});
 }
});
