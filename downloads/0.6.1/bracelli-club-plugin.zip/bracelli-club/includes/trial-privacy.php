<?php
if (!defined('ABSPATH')) { exit; }
function bracelli_trial_privacy_rows($email,$page) {
    global $wpdb;if(!is_email($email)){return array();}$table=bracelli_trial_table();
    return bracelli_trial_db(function()use($wpdb,$table,$email,$page){return $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE email=%s ORDER BY id ASC LIMIT 50 OFFSET %d",strtolower($email),max(0,(int)$page-1)*50),ARRAY_A);});
}
function bracelli_trial_export($email,$page=1) {
    $rows=bracelli_trial_privacy_rows($email,$page);$items=array();
    foreach($rows as $row){$data=array();foreach(array('first_name'=>'Nome referente','last_name'=>'Cognome referente','email'=>'Email','phone'=>'Telefono','discipline_name'=>'Disciplina','course_name'=>'Corso','age_band'=>'Fascia d’età','preferred_day'=>'Giorno preferito','message'=>'Messaggio','created_at'=>'Ricezione UTC','expires_at'=>'Conservazione massima UTC','status'=>'Stato','notes'=>'Note interne','privacy_version'=>'Informativa presa in visione') as $key=>$label){$data[]=array('name'=>$label,'value'=>$row[$key]);}$items[]=array('group_id'=>'bracelli-trials','group_label'=>'Richieste di prova Bracelli Club','item_id'=>'bc-trial-'.$row['id'],'data'=>$data);}
    return array('data'=>$items,'done'=>count($rows)<50);
}
function bracelli_trial_erase($email,$page=1) {
    global $wpdb;$table=bracelli_trial_table();$limits=bracelli_trial_table(true);
    // Always take the first batch: deletions would make OFFSET skip records.
    $rows=bracelli_trial_privacy_rows($email,1);$removed=false;$failed=false;
    foreach($rows as $row){$result=bracelli_trial_db(function()use($wpdb,$table,$row){return $wpdb->delete($table,array('id'=>$row['id']));});$removed=$removed || (bool)$result;$failed=$failed || $result===false;}
    for($offset=0;$offset<48;$offset++){$bucket=(int)floor(time()/HOUR_IN_SECONDS)-$offset;$key=bracelli_trial_digest('email|'.strtolower($email).'|'.$bucket);bracelli_trial_db(function()use($wpdb,$limits,$key){return $wpdb->delete($limits,array('guard_key'=>$key));});}
    return array('items_removed'=>$removed,'items_retained'=>$failed,'messages'=>$failed?array('Cancellazione temporaneamente non disponibile: riprovare.'):array(),'done'=>!$failed && count($rows)<50);
}
function bracelli_trial_exporters($exporters) {$exporters['bracelli-trials']=array('exporter_friendly_name'=>'Richieste di prova Bracelli Club','callback'=>'bracelli_trial_export');return $exporters;}
function bracelli_trial_erasers($erasers) {$erasers['bracelli-trials']=array('eraser_friendly_name'=>'Richieste di prova Bracelli Club','callback'=>'bracelli_trial_erase');return $erasers;}
