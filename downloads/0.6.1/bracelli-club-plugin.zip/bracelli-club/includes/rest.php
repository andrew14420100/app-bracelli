<?php
if (!defined('ABSPATH')) { exit; }
function bracelli_club_register_routes() {
    register_rest_route('bracelli-club/v1', '/home', array(
        'methods' => WP_REST_Server::READABLE,
        'callback' => 'bracelli_club_home',
        'permission_callback' => '__return_true',
    ));
}
function bracelli_club_feed($type) {
    $posts = get_posts(array('post_type' => $type, 'post_status' => 'publish', 'has_password' => false, 'numberposts' => 6, 'orderby' => 'date', 'order' => 'DESC', 'no_found_rows' => true));
    return array_map(function ($post) {
        return array(
            'id' => (int) $post->ID,
            'title' => wp_strip_all_tags(get_the_title($post)),
            'excerpt' => wp_strip_all_tags(get_the_excerpt($post)),
            // Phase 1: publication date, not an event start date.
            'date' => get_post_time('c', true, $post),
        );
    }, $posts);
}
function bracelli_club_home() {
    return rest_ensure_response(array('news' => bracelli_club_feed('bc_news'), 'events' => bracelli_club_feed('bc_event')));
}
