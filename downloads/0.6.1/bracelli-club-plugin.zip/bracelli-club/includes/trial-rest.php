<?php
if (!defined('ABSPATH')) { exit; }
function bracelli_trial_origin_allowed($request) {
    $origin=$request->get_header('origin');$site=wp_parse_url(home_url());
    $expected=$site['scheme'].'://'.$site['host'].(isset($site['port'])?':'.$site['port']:'');
    return (!$origin || rtrim($origin,'/')===$expected) && $request->get_header('sec-fetch-site')!=='cross-site';
}
function bracelli_trial_token($ip,$at=null) {
    $payload=(string)($at ?? time()).'.'.bin2hex(random_bytes(16));
    return $payload.'.'.bracelli_trial_digest('form|'.$payload.'|'.$ip);
}
function bracelli_trial_check_token($token,$ip,$at=null) {
    if(!is_string($token) || !preg_match('/^(\d{10})\.([a-f0-9]{32})\.([a-f0-9]{64})$/D',$token,$parts)){return false;}
    $age=($at ?? time())-(int)$parts[1];
    return $age>=2 && $age<=1800 && hash_equals(bracelli_trial_digest('form|'.$parts[1].'.'.$parts[2].'|'.$ip),$parts[3]);
}
function bracelli_trial_age_band($course) {
    if($course['age']!==''){return mb_substr($course['age'],0,160);}
    if(isset($course['ageRange']['min'],$course['ageRange']['max'])){return $course['ageRange']['min'].'–'.$course['ageRange']['max'].' anni';}
    return '';
}
function bracelli_trial_options() {
    $catalog=bracelli_club_catalog();$courses=$disciplines=array();
    foreach($catalog['courses'] as $course){if($course['trial']){$courses[]=array('id'=>$course['id'],'disciplineId'=>$course['disciplineId'],'name'=>$course['name'],'ageBand'=>bracelli_trial_age_band($course));}}
    $ids=array_column($courses,'disciplineId');
    foreach($catalog['disciplines'] as $discipline){if(in_array($discipline['id'],$ids,true)){$disciplines[]=array('id'=>$discipline['id'],'name'=>$discipline['name']);}}
    return array('disciplines'=>$disciplines,'courses'=>$courses);
}
function bracelli_trial_public_form($request) {
    if(!bracelli_trial_origin_allowed($request)){return new WP_Error('bc_trial_origin','Richiesta non consentita.',array('status'=>403));}
    $settings=bracelli_trial_settings();$contacts=array();
    foreach(array('phone','whatsapp','email','address','directions','office_hours') as $key){$contacts[$key]=$settings[$key];}
    $enabled=$settings['enabled'] && get_option('bc_trial_schema_version')==='1';
    $data=array('enabled'=>$enabled,'contacts'=>$contacts,'privacy'=>$enabled?bracelli_trial_policy($settings):null,'token'=>'','disciplines'=>array(),'courses'=>array());
    if($enabled){
        $rate=bracelli_trial_rate('token',bracelli_trial_ip(),30,600);if(is_wp_error($rate)){return $rate;}
        $data=array_merge($data,bracelli_trial_options());$data['token']=bracelli_trial_token(bracelli_trial_ip());
    }
    $response=rest_ensure_response($data);$response->header('Cache-Control','no-store, max-age=0');return $response;
}
function bracelli_trial_validation($input,$options,$policy) {
    if(!is_array($input)){return new WP_Error('bc_trial_invalid','Controlla i campi del modulo.',array('status'=>400));}
    $errors=array();$clean=array();
    foreach(array('first_name'=>80,'last_name'=>80,'email'=>254,'phone'=>30,'age_band'=>160,'message'=>2000,'privacy_version'=>64,'submission_id'=>64,'website'=>200) as $key=>$max){
        $value=$input[$key] ?? '';
        if(!is_string($value) || mb_strlen($value)>$max){$errors[$key]='Valore non valido o troppo lungo.';$value='';}
        $clean[$key]=$key==='message' ? sanitize_textarea_field($value) : sanitize_text_field($value);
    }
    foreach(array('first_name'=>'Indica il nome del referente adulto.','last_name'=>'Indica il cognome del referente adulto.') as $key=>$message){if(trim($clean[$key])===''){$errors[$key]=$message;}}
    if(!is_email($clean['email']) || preg_match('/[\r\n]/',is_string($input['email'] ?? null)?$input['email']:'')){$errors['email']='Inserisci un indirizzo email valido.';}
    $clean['email']=strtolower(sanitize_email($clean['email']));
    $phone=bracelli_trial_phone($clean['phone']);if($phone===''){$errors['phone']='Inserisci un numero di telefono valido (7–15 cifre).';}$clean['phone']=$phone;
    foreach(array('discipline_id','course_id','preferred_day') as $key){
        $value=$input[$key] ?? 0;
        if((!is_int($value) && !is_string($value)) || !preg_match('/^\d{1,12}$/D',(string)$value)){$errors[$key]='Selezione non valida.';$value=0;}
        $clean[$key]=(int)$value;
    }
    if($clean['preferred_day']>7){$errors['preferred_day']='Seleziona un giorno valido.';}
    $course=null;$discipline=null;
    foreach($options['courses'] as $item){if($item['id']===$clean['course_id']){$course=$item;}}
    if($clean['course_id'] && !$course){$errors['course_id']='Il corso non è più disponibile per una prova.';}
    if($course && !$clean['discipline_id']){$clean['discipline_id']=$course['disciplineId'];}
    foreach($options['disciplines'] as $item){if($item['id']===$clean['discipline_id']){$discipline=$item;}}
    if(!$discipline){$errors['discipline_id']='Seleziona una disciplina con prova disponibile.';}
    if($course && $course['disciplineId']!==$clean['discipline_id']){$errors['course_id']='Il corso non appartiene alla disciplina selezionata.';}
    $bands=array();foreach($options['courses'] as $item){if(($course && $item['id']===$course['id']) || (!$course && $item['disciplineId']===$clean['discipline_id'])){if($item['ageBand']!==''){$bands[]=$item['ageBand'];}}}
    if(($bands && !in_array($clean['age_band'],$bands,true)) || (!$bands && $clean['age_band']!=='')){$errors['age_band']='Seleziona una fascia d’età tra quelle del corso o della disciplina.';}
    if(($input['privacy_acknowledged'] ?? false)!==true){$errors['privacy_acknowledged']='Conferma di aver letto l’informativa privacy.';}
    if($clean['privacy_version']!==$policy['version']){return new WP_Error('bc_trial_privacy_changed','L’informativa è stata aggiornata. Ricaricala e prendine visione prima di inviare.',array('status'=>409,'fields'=>array('privacy_acknowledged'=>'Rileggi l’informativa aggiornata.')));}
    if(!preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/D',$clean['submission_id'])){$errors['submission_id']='Ricarica il modulo prima di inviare.';}
    if(($input['website'] ?? '')!==''){$errors['website']='Invio non accettato.';}
    if($errors){return new WP_Error('bc_trial_invalid','Controlla i campi indicati.',array('status'=>400,'fields'=>$errors));}
    $clean['discipline_name']=mb_substr($discipline['name'],0,200);$clean['course_name']=$course?mb_substr($course['name'],0,200):'';
    return $clean;
}
function bracelli_trial_accepted() {
    $response=new WP_REST_Response(array('received'=>true,'message'=>'Richiesta ricevuta. La segreteria ti contatterà per concordare la prova. L’appuntamento non è ancora confermato.'),202);
    $response->header('Cache-Control','no-store, max-age=0');return $response;
}
function bracelli_trial_submit($request) {
    global $wpdb;
    if(!bracelli_trial_origin_allowed($request)){return new WP_Error('bc_trial_origin','Richiesta non consentita.',array('status'=>403));}
    if(stripos((string)$request->get_header('content-type'),'application/json')!==0 || strlen($request->get_body())>16000){return new WP_Error('bc_trial_format','Formato della richiesta non valido.',array('status'=>400));}
    $settings=bracelli_trial_settings();
    if(!$settings['enabled'] || get_option('bc_trial_schema_version')!=='1'){return new WP_Error('bc_trial_disabled','Le richieste online non sono disponibili.',array('status'=>503));}
    $ip=bracelli_trial_ip();$rate=bracelli_trial_rate('attempt',$ip,30,600);if(is_wp_error($rate)){return $rate;}
    $input=$request->get_json_params();
    if(!is_array($input) || !bracelli_trial_check_token($input['token'] ?? null,$ip)){return new WP_Error('bc_trial_token','Il modulo non è ancora pronto o è scaduto. Attendi qualche secondo oppure ricaricalo.',array('status'=>400));}
    $policy=bracelli_trial_policy($settings);$clean=bracelli_trial_validation($input,bracelli_trial_options(),$policy);if(is_wp_error($clean)){return $clean;}
    $submission=bracelli_trial_digest('submission|'.$clean['submission_id']);
    $fields=array();foreach(array('first_name','last_name','email','phone','discipline_id','course_id','age_band','preferred_day','message','privacy_version') as $key){$fields[$key]=$clean[$key];}
    $fingerprint=bracelli_trial_digest('payload|'.wp_json_encode($fields));$lock='bc_trial_'.substr($fingerprint,0,52);$table=bracelli_trial_table();
    $locked=bracelli_trial_db(function()use($wpdb,$lock){return $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock));});
    if((string)$locked!=='1'){return new WP_Error('bc_trial_busy','Invio già in corso. Attendi qualche secondo e riprova.',array('status'=>429));}
    $id=0;
    try{
        $existing=bracelli_trial_db(function()use($wpdb,$table,$submission){return $wpdb->get_row($wpdb->prepare("SELECT fingerprint FROM $table WHERE submission_hash=%s",$submission),ARRAY_A);});
        if($existing){return hash_equals($existing['fingerprint'],$fingerprint)?bracelli_trial_accepted():new WP_Error('bc_trial_conflict','Il modulo è cambiato. Ricaricalo prima di inviare.',array('status'=>409));}
        $cutoff=gmdate('Y-m-d H:i:s',time()-DAY_IN_SECONDS);
        $duplicate=bracelli_trial_db(function()use($wpdb,$table,$fingerprint,$cutoff){return $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE fingerprint=%s AND created_at>=%s LIMIT 1",$fingerprint,$cutoff));});
        if($duplicate){return bracelli_trial_accepted();}
        foreach(array(array('submission',$ip,5,600),array('email',$clean['email'],3,HOUR_IN_SECONDS)) as $guard){$rate=bracelli_trial_rate(...$guard);if(is_wp_error($rate)){return $rate;}}
        $now=current_time('mysql',true);
        $row=$fields+array('discipline_name'=>$clean['discipline_name'],'course_name'=>$clean['course_name'],'created_at'=>$now,'updated_at'=>$now,'expires_at'=>gmdate('Y-m-d H:i:s',time()+$settings['retention_days']*DAY_IN_SECONDS),'privacy_notice'=>$policy['text'],'status'=>'new','notes'=>'','history'=>wp_json_encode(array(array('at'=>$now,'actor'=>0,'event'=>'received'))),'submission_hash'=>$submission,'fingerprint'=>$fingerprint,'mail_status'=>'pending','mail_attempts'=>0,'mail_error'=>'');
        $saved=bracelli_trial_db(function()use($wpdb,$table,$row){return $wpdb->insert($table,$row);});
        if(!$saved){return new WP_Error('bc_trial_storage','Non è stato possibile registrare la richiesta. Riprova tra poco.',array('status'=>503));}
        $id=(int)$wpdb->insert_id;
    }finally{bracelli_trial_db(function()use($wpdb,$lock){return $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));});}
    // The record is durable before trying email; failure never rolls back receipt.
    bracelli_trial_notify($id);return bracelli_trial_accepted();
}
function bracelli_trial_routes() {
    register_rest_route('bracelli-club/v1','/trial-form',array('methods'=>WP_REST_Server::READABLE,'callback'=>'bracelli_trial_public_form','permission_callback'=>'__return_true'));
    register_rest_route('bracelli-club/v1','/trial-requests',array('methods'=>WP_REST_Server::CREATABLE,'callback'=>'bracelli_trial_submit','permission_callback'=>'__return_true'));
}
function bracelli_trial_response_headers($response,$server,$request) {
    if(strpos($request->get_route(),'/bracelli-club/v1/trial-')===0){$response->header('Cache-Control','no-store, max-age=0');if($response->get_status()===429){$response->header('Retry-After','600');}}
    return $response;
}
