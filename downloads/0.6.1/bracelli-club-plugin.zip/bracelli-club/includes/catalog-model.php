<?php
/** Domain schema and validation. No changes to WordPress posts or pages. */
if (!defined('ABSPATH')) { exit; }
function bracelli_club_types() {
    return array('bc_discipline' => 'Discipline', 'bc_course' => 'Corsi', 'bc_instructor' => 'Istruttori', 'bc_slot' => 'Orari settimanali');
}
function bracelli_club_schema($type) {
    $text = function ($label) { return array('label' => $label, 'kind' => 'text'); };
    $relation = function ($label, $target, $many = false) { return array('label' => $label, 'kind' => $many ? 'relations' : 'relation', 'target' => $target); };
    $select = function ($label, $options) { return array('label' => $label, 'kind' => 'select', 'options' => $options); };
    $bool = function ($label) { return array('label' => $label, 'kind' => 'bool'); };
    $all = array(
        'bc_discipline' => array(
            'hidden' => $bool('Nascondi dal catalogo pubblico'),
            'ages' => array('label' => 'Fasce d’età (una per riga)', 'kind' => 'lines'),
            'benefits' => array('label' => 'Benefici (uno per riga)', 'kind' => 'lines'),
            'photos' => array('label' => 'Fotografie', 'kind' => 'media_images'),
            'video' => array('label' => 'Video dalla libreria media', 'kind' => 'media_video'),
            'intensity' => $select('Intensità', array('' => 'Non definita', 'low' => 'Bassa', 'medium' => 'Media', 'high' => 'Alta')),
            'environment' => $select('Ambiente', array('' => 'Non definito', 'indoor' => 'Al chiuso', 'outdoor' => 'All’aperto', 'mixed' => 'Misto')),
            'format' => $select('Modalità', array('' => 'Non definita', 'individual' => 'Individuale', 'group' => 'Gruppo', 'mixed' => 'Mista')),
            'goals' => array('label' => 'Obiettivi Explorer: etichette o ID del questionario (uno per riga)', 'kind' => 'lines'),
            'preferences' => array('label' => 'Preferenze Explorer', 'kind' => 'choices', 'options' => function_exists('bracelli_club_explorer_settings') ? array_column(bracelli_club_explorer_settings()['preferences'],'label','id') : array()),
        ),
        'bc_course' => array(
            'discipline' => $relation('Disciplina (obbligatoria)', 'bc_discipline'),
            'age' => $text('Fascia d’età (descrizione)'),
            'age_min' => array('label'=>'Età minima Explorer (anni inclusi; vuota: escluso dal quiz)', 'kind'=>'age'),
            'age_max' => array('label'=>'Età massima Explorer (anni inclusi)', 'kind'=>'age'),
            'level' => $select('Livello', array('all' => 'Tutti i livelli', 'beginner' => 'Base', 'intermediate' => 'Intermedio', 'advanced' => 'Avanzato')),
            'instructors' => $relation('Istruttori assegnati', 'bc_instructor', true),
            'room' => $text('Sala (testo precedente, usato solo senza sala collegata)'),
            'room_id' => array('label'=>'Sala dal registro condiviso','kind'=>'room'), 'trial' => $bool('Lezione di prova disponibile'), 'active' => $bool('Corso attivo'),
        ),
        'bc_instructor' => array('photo' => array('label' => 'Fotografia', 'kind' => 'media_image')),
        'bc_slot' => array(
            'course' => $relation('Corso (obbligatorio)', 'bc_course'),
            'day' => $select('Giorno', array('1' => 'Lunedì', '2' => 'Martedì', '3' => 'Mercoledì', '4' => 'Giovedì', '5' => 'Venerdì', '6' => 'Sabato', '7' => 'Domenica')),
            'start' => array('label' => 'Inizio', 'kind' => 'time'), 'end' => array('label' => 'Fine', 'kind' => 'time'),
            'room' => $text('Sala precedente (vuota: eredita dal corso)'),
            'room_id' => array('label'=>'Sala dal registro (nessuna: eredita dal corso)','kind'=>'room'),
            'instructor' => $relation('Istruttore (assegnato al corso)', 'bc_instructor'),
            'suspended' => $bool('Orario sospeso temporaneamente (togliere la spunta per ripristinarlo)'),
        ),
    );
    return $all[$type] ?? array();
}
function bracelli_club_meta($id, $key, $default = '') {
    $value = get_post_meta($id, '_bc_' . $key, true);
    return $value === '' ? $default : $value;
}
function bracelli_club_relation_valid($id, $type) {
    $post = get_post($id);
    return $post && $post->post_type === $type && !in_array($post->post_status, array('trash', 'auto-draft'), true);
}
function bracelli_club_validate($type, $input) {
    $clean = array();
    foreach (bracelli_club_schema($type) as $key => $field) {
        $value = $input[$key] ?? '';
        $kind = $field['kind'];
        if ($kind==='room') {
            if(!is_scalar($value) || ($value!=='' && !ctype_digit((string)$value))) {return new WP_Error('bc_room','Sala non valida.');}
            $value=absint($value);if($value && !term_exists($value,'bc_room')){return new WP_Error('bc_room','Selezionare una sala esistente.');}
        } elseif ($kind === 'choices') {
            if ($value === '') { $value=array(); }
            if (!is_array($value)) { return new WP_Error('bc_choices','Preferenze non valide.'); }
            foreach ($value as $choice) { if (!is_string($choice) || !array_key_exists($choice,$field['options'])) { return new WP_Error('bc_choices','Preferenza non selezionabile: aggiornare la scheda.'); } }
            $value=array_values(array_unique($value));
        } elseif (in_array($kind, array('relations', 'media_images'), true)) {
            $values = is_array($value) ? $value : explode(',', (string) $value);
            $value = array_values(array_unique(array_filter(array_map('absint', $values))));
            foreach ($value as $id) {
                if ($kind === 'relations' ? !bracelli_club_relation_valid($id, $field['target']) : !wp_attachment_is_image($id)) {
                    return new WP_Error('bc_invalid_reference', 'Riferimento non valido: ' . $field['label']);
                }
            }
        } elseif ($kind === 'lines') {
            $value = array_values(array_unique(array_filter(array_map('sanitize_text_field', preg_split('/\R/u', is_scalar($value) ? (string) $value : '')))));
        } elseif ($kind === 'bool') {
            $value = $value === '1' || $value === 1 || $value === true;
        } else {
            if (!is_scalar($value)) { return new WP_Error('bc_invalid_value', 'Valore non valido: ' . $field['label']); }
            $value = sanitize_text_field((string) $value);
            if ($kind === 'age' && $value !== '' && (!preg_match('/^\d{1,3}$/D',$value) || (int)$value>120)) { return new WP_Error('bc_age','Le età devono essere interi tra 0 e 120.'); }
            if ($kind === 'age' && $value !== '') { $value=(int)$value; }
            if ($kind === 'select' && !array_key_exists($value, $field['options'])) {
                return new WP_Error('bc_invalid_choice', 'Selezione non valida: ' . $field['label']);
            }
            if ($kind === 'time' && !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $value)) {
                return new WP_Error('bc_invalid_time', 'Orario non valido: ' . $field['label']);
            }
            if (in_array($kind, array('relation', 'media_image', 'media_video'), true)) {
                $value = absint($value);
                if ($kind === 'relation' && !bracelli_club_relation_valid($value, $field['target'])) {
                    return new WP_Error('bc_invalid_reference', 'Selezionare un riferimento valido: ' . $field['label']);
                }
                if ($value && $kind === 'media_image' && !wp_attachment_is_image($value)) {
                    return new WP_Error('bc_invalid_media', 'Selezionare una fotografia valida.');
                }
                if ($value && $kind === 'media_video' && strpos((string) get_post_mime_type($value), 'video/') !== 0) {
                    return new WP_Error('bc_invalid_media', 'Selezionare un video valido.');
                }
            }
        }
        $clean[$key] = $value;
    }
    if ($type === 'bc_course' && (($clean['age_min']==='') !== ($clean['age_max']==='') || ($clean['age_min']!=='' && $clean['age_min']>$clean['age_max']))) {
        return new WP_Error('bc_age','Inserire entrambe le età, con minima non superiore alla massima, oppure lasciare entrambe vuote.');
    }
    if ($type === 'bc_slot') {
        if ($clean['end'] <= $clean['start']) { return new WP_Error('bc_time_range', 'La fine deve essere successiva all’inizio, nello stesso giorno.'); }
        if (!in_array($clean['instructor'], array_map('intval', (array) bracelli_club_meta($clean['course'], 'instructors', array())), true)) {
            return new WP_Error('bc_instructor_mismatch', 'L’istruttore deve essere assegnato al corso selezionato.');
        }
    }
    return $clean;
}
function bracelli_club_register_catalog() {
    foreach (bracelli_club_types() as $type => $label) {
        register_post_type($type, array(
            'label' => $label, 'public' => false, 'show_ui' => true, 'show_in_rest' => false,
            'show_in_menu' => 'bracelli-club', 'supports' => array('title', 'editor', 'excerpt', 'page-attributes'),
            'capability_type' => 'post', 'map_meta_cap' => true,
            'capabilities' => bracelli_content_caps(), 'rewrite' => false, 'has_archive' => false,
        ));
    }
    register_taxonomy('bc_category', 'bc_discipline', array(
        'label' => 'Categorie discipline', 'public' => false, 'show_ui' => true, 'show_admin_column' => true,
        'capabilities'=>array('manage_terms'=>'bracelli_manage_content','edit_terms'=>'bracelli_manage_content','assign_terms'=>'bracelli_manage_content','delete_terms'=>'bracelli_delete_data'),
        'hierarchical' => true, 'rewrite' => false, 'show_in_rest' => false,
    ));
}
// Deleting a source clears references and drafts dependents instead of deleting editorial data.
function bracelli_club_before_delete($id, $post) {
    if (!array_key_exists($post->post_type, bracelli_club_types())) { return; }
    if ($post->post_type === 'bc_discipline' || $post->post_type === 'bc_course') {
        $target = $post->post_type === 'bc_discipline' ? 'bc_course' : 'bc_slot';
        $key = $target === 'bc_course' ? 'discipline' : 'course';
        foreach (get_posts(array('post_type' => $target, 'post_status' => array('publish','draft','pending','private','future','trash'), 'numberposts' => -1, 'meta_key' => '_bc_' . $key, 'meta_value' => $id)) as $dependent) {
            update_post_meta($dependent->ID, '_bc_' . $key, 0);
            if ($dependent->post_status !== 'trash') { wp_update_post(array('ID' => $dependent->ID, 'post_status' => 'draft')); }
        }
    }
    if ($post->post_type === 'bc_instructor') {
        foreach (get_posts(array('post_type' => 'bc_course', 'post_status' => array('publish','draft','pending','private','future','trash'), 'numberposts' => -1)) as $course) {
            $ids = array_map('intval', (array) bracelli_club_meta($course->ID, 'instructors', array()));
            if (in_array($id, $ids, true)) { update_post_meta($course->ID, '_bc_instructors', array_values(array_diff($ids, array($id)))); }
        }
        foreach (get_posts(array('post_type' => 'bc_slot', 'post_status' => array('publish','draft','pending','private','future','trash'), 'numberposts' => -1, 'meta_key' => '_bc_instructor', 'meta_value' => $id)) as $slot) {
            update_post_meta($slot->ID, '_bc_instructor', 0);
            if ($slot->post_status !== 'trash') { wp_update_post(array('ID' => $slot->ID, 'post_status' => 'draft')); }
        }
    }
}
