<?php
/** Explorer configuration. Visitor answers never reach this code. */
if (!defined('ABSPATH')) { exit; }
function bracelli_club_explorer_defaults() {
    return array(
        'version' => 1,
        'weights' => array('goal' => 4, 'preference' => 3, 'day' => 2),
        'goals' => array(
            array('id'=>'fun','label'=>'Divertimento'), array('id'=>'coordination','label'=>'Coordinazione'),
            array('id'=>'movement','label'=>'Movimento'), array('id'=>'social','label'=>'Socializzazione'),
            array('id'=>'discipline','label'=>'Disciplina'), array('id'=>'wellbeing','label'=>'Benessere'), array('id'=>'competition','label'=>'Competizione'),
        ),
        'preferences' => array(
            array('id'=>'individual','label'=>'Attività individuali'), array('id'=>'team','label'=>'Attività di squadra'),
            array('id'=>'artistic','label'=>'Attività artistiche'), array('id'=>'motor','label'=>'Attività motorie'), array('id'=>'martial','label'=>'Arti marziali'),
        ),
    );
}
function bracelli_club_explorer_choices($rows) {
    if (!is_array($rows) || count($rows)<1 || count($rows)>30) { return new WP_Error('bc_choices','Inserire da 1 a 30 categorie per elenco.'); }
    $result=$ids=$labels=array();
    foreach ($rows as $row) {
        if (!is_array($row) || !isset($row['id'],$row['label']) || !is_string($row['id']) || !is_string($row['label'])) { return new WP_Error('bc_choices','Categoria non valida.'); }
        $id=$row['id']; $label=sanitize_text_field($row['label']); $normalized=strtolower(remove_accents(trim($label)));
        if (!preg_match('/^[a-z][a-z0-9_-]{0,39}$/D',$id) || in_array($id,array('none','any'),true) || $label==='' || mb_strlen($label)>80 || in_array($id,$ids,true) || in_array($normalized,$labels,true)) {
            return new WP_Error('bc_choices','ID e nomi devono essere univoci; ID minuscoli senza spazi, nome massimo 80 caratteri. none e any sono riservati.');
        }
        $ids[]=$id; $labels[]=$normalized; $result[]=array('id'=>$id,'label'=>$label);
    }
    return $result;
}
function bracelli_club_explorer_validate_settings($input) {
    if (!is_array($input) || !isset($input['weights']) || !is_array($input['weights'])) { return new WP_Error('bc_settings','Configurazione non valida.'); }
    $clean=array('version'=>1,'weights'=>array());
    foreach (array('goal','preference','day') as $key) {
        $value=$input['weights'][$key] ?? null;
        if ((!is_int($value) && !is_string($value)) || !preg_match('/^\d{1,2}$/D',(string)$value) || (int)$value>20) { return new WP_Error('bc_weights','Ogni peso deve essere un intero tra 0 e 20.'); }
        $clean['weights'][$key]=(int)$value;
    }
    if (!array_sum($clean['weights'])) { return new WP_Error('bc_weights','Almeno un peso deve essere maggiore di zero.'); }
    foreach (array('goals','preferences') as $key) {
        $rows=bracelli_club_explorer_choices($input[$key] ?? null);
        if (is_wp_error($rows)) { return $rows; } $clean[$key]=$rows;
    }
    return $clean;
}
function bracelli_club_explorer_settings() {
    $saved=get_option('bc_explorer_settings',null);
    $validated=bracelli_club_explorer_validate_settings($saved);
    return is_wp_error($validated) ? bracelli_club_explorer_defaults() : $validated;
}
function bracelli_club_explorer_apply($input, $nonce, $reset=false) {
    if (!bracelli_can('manage_settings')) { return new WP_Error('bc_forbidden','Permessi insufficienti.'); }
    if (!is_string($nonce) || !wp_verify_nonce($nonce,'bc_explorer_settings')) { return new WP_Error('bc_nonce','Verifica di sicurezza non valida.'); }
    $settings=$reset ? bracelli_club_explorer_defaults() : bracelli_club_explorer_validate_settings($input);
    if (is_wp_error($settings)) { return $settings; }
    update_option('bc_explorer_settings',$settings,false);bracelli_admin_audit('explorer_settings');
    return $settings;
}
function bracelli_club_explorer_parse_lines($text) {
    if (!is_string($text)) { return array(); }
    $rows=array();
    foreach (preg_split('/\R/u',trim($text)) as $line) {
        $parts=explode('|',$line,2); $rows[]=array('id'=>trim($parts[0]),'label'=>trim($parts[1] ?? ''));
    }
    return $rows;
}
function bracelli_club_explorer_save_settings() {
    $input=isset($_POST['explorer']) && is_array($_POST['explorer']) ? wp_unslash($_POST['explorer']) : array();
    foreach (array('goals','preferences') as $key) { $input[$key]=bracelli_club_explorer_parse_lines($input[$key] ?? null); }
    $result=bracelli_club_explorer_apply($input,isset($_POST['bc_nonce']) ? wp_unslash($_POST['bc_nonce']) : '',isset($_POST['bc_reset']) && $_POST['bc_reset']==='1');
    if (is_wp_error($result)) { wp_die(esc_html($result->get_error_message()),'Explorer',array('response'=>403)); }
    bracelli_admin_flash('Configurazione Explorer salvata.');
    wp_safe_redirect(admin_url('admin.php?page=bc-explorer&saved=1')); exit;
}
function bracelli_club_explorer_age_range($id) {
    $min=bracelli_club_meta($id,'age_min'); $max=bracelli_club_meta($id,'age_max');
    if (!preg_match('/^\d{1,3}$/D',(string)$min) || !preg_match('/^\d{1,3}$/D',(string)$max) || (int)$min>(int)$max || (int)$max>120) { return null; }
    return array('min'=>(int)$min,'max'=>(int)$max);
}
function bracelli_club_explorer_diagnostics() {
    $config=bracelli_club_explorer_settings(); $issues=array();
    $goal_values=array_merge(array_column($config['goals'],'id'),array_column($config['goals'],'label'));
    $normalize=function($value){return strtolower(remove_accents(trim($value)));};
    $goal_values=array_map($normalize,$goal_values); $preference_ids=array_column($config['preferences'],'id');
    foreach (get_posts(array('post_type'=>'bc_discipline','post_status'=>array('publish','draft','pending','private','future'),'numberposts'=>-1)) as $discipline) {
        $messages=array(); $goals=(array)bracelli_club_meta($discipline->ID,'goals',array());
        if (!array_intersect(array_map($normalize,$goals),$goal_values)) { $messages[]='Nessun obiettivo corrisponde al questionario'; }
        if (!array_intersect((array)bracelli_club_meta($discipline->ID,'preferences',array()),$preference_ids)) { $messages[]='Preferenze non configurate o non più selezionabili'; }
        $courses=get_posts(array('post_type'=>'bc_course','post_status'=>'publish','has_password'=>false,'numberposts'=>-1,'meta_key'=>'_bc_discipline','meta_value'=>$discipline->ID));
        $usable=array_filter($courses,function($course){return bracelli_club_meta($course->ID,'active') && bracelli_club_explorer_age_range($course->ID)!==null;});
        if (!$usable) { $messages[]='Nessun corso pubblico attivo con età numerica valida'; }
        foreach ($courses as $course) { if (bracelli_club_meta($course->ID,'active') && bracelli_club_explorer_age_range($course->ID)===null) { $messages[]='Fascia numerica mancante: ' . $course->post_title; } }
        if ($messages) { $issues[]=array('id'=>$discipline->ID,'name'=>$discipline->post_title,'messages'=>$messages); }
    }
    return $issues;
}
function bracelli_club_explorer_menu() {
    add_submenu_page('bracelli-club','Explorer intelligente','Explorer intelligente',(bracelli_can('manage_settings')?'bracelli_manage_settings':'bracelli_manage_content'),'bc-explorer','bracelli_club_explorer_page');
}
function bracelli_club_explorer_page() {
    if (!bracelli_can('manage_content') && !bracelli_can('manage_settings')) { wp_die('Permessi insufficienti.'); }
    $config=bracelli_club_explorer_settings();
    if (isset($_GET['saved']) && $_GET['saved']==='1') { echo '<div class="notice notice-success"><p>Impostazioni Explorer salvate.</p></div>'; }
    echo '<div class="wrap"><h1>Explorer intelligente</h1><p>Età: requisito obbligatorio sui corsi. Punteggio per obiettivo, preferenza e giorno corrispondente. Nessuna valutazione medica o percentuale scientifica.</p>';
    if (bracelli_can('manage_settings')) {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="bc_explorer_settings">';
        wp_nonce_field('bc_explorer_settings','bc_nonce');
        echo '<h2>Pesi</h2><p>Interi da 0 a 20; almeno uno positivo. Età e numero di corsi non aggiungono punti.</p>';
        foreach (array('goal'=>'Obiettivo corrispondente','preference'=>'Preferenza corrispondente','day'=>'Giorno preferito presente') as $key=>$label) {
            echo '<p><label>' . esc_html($label) . ' <input type="number" min="0" max="20" required name="explorer[weights][' . esc_attr($key) . ']" value="' . esc_attr($config['weights'][$key]) . '"></label></p>';
        }
        echo '<p>Una categoria per riga, formato <code>id|Etichetta</code>. ID stabili e univoci, senza spazi; non rinominare gli ID già assegnati senza aggiornare le discipline. Obiettivi: inserire nelle discipline la stessa etichetta o ID, senza dedurre sinonimi.</p>';
        foreach (array('goals'=>'Obiettivi selezionabili','preferences'=>'Preferenze selezionabili') as $key=>$label) {
            $lines=array_map(function($row){return $row['id'].'|'.$row['label'];},$config[$key]);
            echo '<p><label for="explorer-' . esc_attr($key) . '"><strong>' . esc_html($label) . '</strong></label><br><textarea id="explorer-' . esc_attr($key) . '" name="explorer[' . esc_attr($key) . ']" rows="9" cols="60">' . esc_textarea(implode("\n",$lines)) . '</textarea></p>';
        }
        submit_button('Salva impostazioni');
        echo '<button class="button" type="submit" name="bc_reset" value="1">Ripristina impostazioni predefinite</button></form>';
    } else { echo '<p>Solo gli amministratori possono modificare pesi e categorie. Gli editor possono configurare le discipline e provare il motore.</p>'; }
    echo '<h2>Dati da completare</h2><ul>';
    $issues=bracelli_club_explorer_diagnostics();
    foreach ($issues as $issue) { echo '<li><a href="' . esc_url(get_edit_post_link($issue['id'])) . '">' . esc_html($issue['name']) . '</a>: ' . esc_html(implode('; ',$issue['messages'])) . '</li>'; }
    if (!$issues) { echo '<li>Nessuna lacuna rilevata nei metadati essenziali.</li>'; }
    echo '</ul><h2>Simulazione senza salvataggio</h2><p>Usa solo il catalogo pubblico. Le risposte simulate non vengono inviate al server né modificano i contenuti. I collegamenti pubblici sono disabilitati in questa anteprima.</p><div id="bc-explorer-preview" class="explorer-widget" data-api="' . esc_url(rest_url('bracelli-club/v1/catalog')) . '"></div></div>';
}
function bracelli_club_explorer_assets($hook) {
    if ($hook!=='bracelli-club_page_bc-explorer') { return; }
    wp_enqueue_style('bc-explorer',plugins_url('assets/explorer.css',dirname(__DIR__).'/bracelli-club.php'),array(),'0.3.0');
    wp_enqueue_script('bc-explorer-preview',plugins_url('assets/explorer-admin.js',dirname(__DIR__).'/bracelli-club.php'),array(),'0.3.0',true);
}
function bracelli_club_explorer_module_tag($tag,$handle) {
    if ($handle!=='bc-explorer-preview') { return $tag; }
    $tag=preg_replace('/\s+type=([\'"]).*?\1/i','',$tag,1);
    return str_replace('<script ','<script type="module" ',$tag);
}
