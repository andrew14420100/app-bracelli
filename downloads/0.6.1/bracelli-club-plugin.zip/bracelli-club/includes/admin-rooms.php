<?php
if (!defined('ABSPATH')) { exit; }
function bracelli_rooms_register(){register_taxonomy('bc_room',array('bc_course','bc_slot'),array('label'=>'Sale','public'=>false,'show_ui'=>true,'show_in_rest'=>false,'meta_box_cb'=>false,'rewrite'=>false,'capabilities'=>array('manage_terms'=>'bracelli_manage_content','edit_terms'=>'bracelli_manage_content','assign_terms'=>'bracelli_manage_content','delete_terms'=>'bracelli_delete_data')));}
function bracelli_room_id($id){$terms=wp_get_object_terms($id,'bc_room',array('fields'=>'ids'));return is_wp_error($terms)||!$terms?0:(int)$terms[0];}
function bracelli_room_name($id){$room=bracelli_room_id($id);$term=$room?get_term($room,'bc_room'):null;return $term&&!is_wp_error($term)?$term->name:bracelli_club_meta($id,'room');}
function bracelli_rooms_import(){
    foreach(get_posts(array('post_type'=>array('bc_course','bc_slot'),'post_status'=>array('publish','draft','private','pending','future','trash'),'numberposts'=>-1)) as $post){
        $name=trim((string)bracelli_club_meta($post->ID,'room'));if($name===''||bracelli_room_id($post->ID)){continue;}
        $term=term_exists($name,'bc_room');if(!$term){$term=wp_insert_term($name,'bc_room');}if(!is_wp_error($term)){wp_set_object_terms($post->ID,array((int)(is_array($term)?$term['term_id']:$term)),'bc_room',false);}
    }
}
function bracelli_room_deleted($id,$tt,$taxonomy,$term,$objects){if($taxonomy!=='bc_room'){return;}foreach($objects as $object){update_post_meta($object,'_bc_room',$term->name);}bracelli_admin_audit('room_delete',1,$id);}
function bracelli_slot_room($clean){if(!empty($clean['room_id'])){$term=get_term((int)$clean['room_id'],'bc_room');if($term&&!is_wp_error($term)){return $term->name;}}return $clean['room']!==''?$clean['room']:bracelli_room_name((int)$clean['course']);}
function bracelli_schedule_conflicts($id,$clean){
    if(!empty($clean['suspended'])){return array();}$conflicts=array();$room=mb_strtolower(trim(bracelli_slot_room($clean)));
    foreach(get_posts(array('post_type'=>'bc_slot','post_status'=>'publish','post__not_in'=>array((int)$id),'numberposts'=>-1)) as $other){
        if(bracelli_club_meta($other->ID,'suspended') || (int)bracelli_club_meta($other->ID,'day')!==(int)$clean['day']){continue;}
        $course=(int)bracelli_club_meta($other->ID,'course');if(!bracelli_club_relation_valid($course,'bc_course')||get_post_status($course)!=='publish'||!bracelli_club_meta($course,'active')){continue;}
        $start=bracelli_club_meta($other->ID,'start');$end=bracelli_club_meta($other->ID,'end');if($clean['start']>=$end||$clean['end']<=$start){continue;}
        $otherRoom=bracelli_room_name($other->ID)?:bracelli_room_name($course);$reasons=array();if($room!==''&&$room===mb_strtolower(trim($otherRoom))){$reasons[]='stessa sala';}if((int)$clean['instructor']===(int)bracelli_club_meta($other->ID,'instructor')){$reasons[]='stesso istruttore';}
        if($reasons){$conflicts[]=array('id'=>(int)$other->ID,'course'=>get_the_title($course),'start'=>$start,'end'=>$end,'reasons'=>$reasons);}
    }
    return $conflicts;
}
function bracelli_schedule_check($id,$clean,$override=false,$reason=''){
    $conflicts=bracelli_schedule_conflicts($id,$clean);if(!$conflicts){return array();}
    if(!$override || !bracelli_can('override_schedule') || !is_string($reason) || mb_strlen(trim($reason))<10 || mb_strlen($reason)>500){
        $messages=array_map(function($c){return '#'.$c['id'].' '.$c['course'].' '.$c['start'].'–'.$c['end'].' ('.implode(', ',$c['reasons']).')';},$conflicts);
        return new WP_Error('bc_overlap','Sovrapposizione: '.implode('; ',$messages).'. Correggere l’orario oppure richiedere un’eccezione autorizzata con motivazione di almeno 10 caratteri.');
    }
    return array('at'=>current_time('mysql',true),'actor'=>get_current_user_id(),'reason'=>sanitize_textarea_field($reason),'conflicts'=>array_column($conflicts,'id'),'signature'=>hash('sha256',wp_json_encode($clean)));
}
function bracelli_content_filter_ui($type){
    if(!in_array($type,array('bc_course','bc_slot','bc_discipline'),true)){return;}
    $fields=$type==='bc_discipline'?array('bc_category_filter'=>'Categorie'):array('bc_room_filter'=>'Sale');
    foreach($fields as $key=>$label){$taxonomy=$key==='bc_room_filter'?'bc_room':'bc_category';echo '<label class="screen-reader-text" for="'.esc_attr($key).'">'.esc_html($label).'</label><select id="'.esc_attr($key).'" name="'.esc_attr($key).'"><option value="">'.esc_html($label).'</option>';foreach(get_terms(array('taxonomy'=>$taxonomy,'hide_empty'=>false)) as $term){echo '<option value="'.(int)$term->term_id.'" '.selected((string)($term->term_id),(string)($_GET[$key]??''),false).'>'.esc_html($term->name).'</option>';}echo '</select>';}
    if($type==='bc_course'){echo '<label class="screen-reader-text" for="bc_discipline_filter">Disciplina</label><select id="bc_discipline_filter" name="bc_discipline_filter"><option value="">Tutte le discipline</option>';foreach(get_posts(array('post_type'=>'bc_discipline','post_status'=>array('publish','draft','private','pending'),'numberposts'=>-1)) as $d){echo '<option value="'.(int)$d->ID.'" '.selected((string)$d->ID,(string)($_GET['bc_discipline_filter']??''),false).'>'.esc_html($d->post_title).'</option>';}echo '</select>';}
}
function bracelli_content_filter_query($query){
    if(!is_admin()||!$query->is_main_query()||!in_array($query->get('post_type'),array('bc_course','bc_slot','bc_discipline'),true)){return;}
    foreach(array('bc_room_filter'=>'bc_room','bc_category_filter'=>'bc_category') as $key=>$taxonomy){if(isset($_GET[$key])&&is_scalar($_GET[$key])&&absint($_GET[$key])){$query->set('tax_query',array(array('taxonomy'=>$taxonomy,'field'=>'term_id','terms'=>absint($_GET[$key]))));}}
    if($query->get('post_type')==='bc_course'&&isset($_GET['bc_discipline_filter'])&&is_scalar($_GET['bc_discipline_filter'])&&absint($_GET['bc_discipline_filter'])){$query->set('meta_query',array(array('key'=>'_bc_discipline','value'=>absint($_GET['bc_discipline_filter']),'type'=>'NUMERIC')));}
}
function bracelli_schedule_redirect($location,$id){if(get_transient('bc_error_'.get_current_user_id().'_'.$id)){return remove_query_arg('message',$location);}return $location;}
function bracelli_schedule_columns($columns){$columns['bc_conflicts']='Verifica sovrapposizioni';return $columns;}
function bracelli_schedule_column($column,$id){
    if($column!=='bc_conflicts'){return;}$input=array();foreach(bracelli_club_schema('bc_slot') as $key=>$field){$input[$key]=$key==='room_id'?bracelli_room_id($id):bracelli_club_meta($id,$key);}$clean=bracelli_club_validate('bc_slot',$input);if(is_wp_error($clean)){echo 'Da completare';return;}$conflicts=bracelli_schedule_conflicts($id,$clean);if(!$conflicts){echo 'Nessuna rilevata';return;}
    echo get_post_meta($id,'_bc_overlap_exception',true)?'Eccezione registrata · ':'Da verificare · ';foreach($conflicts as $other){echo '<a href="'.esc_url(get_edit_post_link($other['id'])).'">#'.(int)$other['id'].'</a> ';}
}
