<?php
if (!defined('ABSPATH')) { exit; }
function bracelli_club_admin_menu() {
    $title='Bracelli Club';if(bracelli_can('view_trials')){global $wpdb;$new=(int)$wpdb->get_var('SELECT COUNT(*) FROM '.bracelli_trial_table()." WHERE status='new'");if($new){$title.=' <span class="awaiting-mod"><span class="pending-count">'.$new.'</span></span>';}}
    add_menu_page('Bracelli Club', 'Bracelli Club', 'bracelli_access', 'bracelli-club', 'bracelli_dashboard', 'dashicons-groups', 26);
    foreach($GLOBALS['menu'] as &$item){if($item[2]==='bracelli-club'){$item[0]=$title;break;}}unset($item);
    add_submenu_page('bracelli-club', 'Categorie discipline', 'Categorie', 'bracelli_manage_content', 'edit-tags.php?taxonomy=bc_category&post_type=bc_discipline');
}
function bracelli_club_admin_intro() {
    echo '<div class="wrap"><h1>Bracelli Club</h1><p>Gestisci discipline, istruttori, corsi e orari dai sottomenu. I contenuti restano separati da articoli e pagine del sito.</p><p>Ordine consigliato: discipline e istruttori → corsi → orari. Per nascondere un contenuto usa Bozza; per una disciplina puoi anche usare Nascondi. Per i corsi verifica Corso attivo.</p><p>Gli orari sono settimanali, senza stagioni. Una sospensione resta attiva finché la segreteria non toglie la spunta.</p></div>';
}
function bracelli_club_add_boxes() {
    foreach (bracelli_club_types() as $type => $label) {
        add_meta_box('bc-details', 'Dati Bracelli Club', 'bracelli_club_render_box', $type, 'normal', 'high');
    }
}
function bracelli_club_render_box($post) {
    wp_nonce_field('bc_save_' . $post->ID, 'bc_nonce');
    echo '<p>Nome nel titolo, descrizione/presentazione nell’editor; descrizione breve nel riassunto. Usa “Attributi → Ordinamento” per l’ordine di visualizzazione.</p>';
    $pending=get_transient('bc_pending_'.get_current_user_id().'_'.$post->ID);$pending=is_array($pending)?$pending:array();delete_transient('bc_pending_'.get_current_user_id().'_'.$post->ID);
    foreach (bracelli_club_schema($post->post_type) as $key => $field) {
        $value = bracelli_club_meta($post->ID, $key, $field['kind'] === 'select' ? (string) array_key_first($field['options']) : '');
        if(array_key_exists($key,$pending)){$value=$pending[$key];}
        $name = 'bc[' . $key . ']'; $dom_id = 'bc-' . $key;
        echo '<p><label for="' . esc_attr($dom_id) . '"><strong>' . esc_html($field['label']) . '</strong></label><br>';
        if ($field['kind']==='room') {
            $selected_room=isset($pending['room_id'])?absint($pending['room_id']):bracelli_room_id($post->ID);echo '<select id="'.esc_attr($dom_id).'" name="'.esc_attr($name).'"><option value="0">Nessuna / eredita dal corso</option>';
            foreach(get_terms(array('taxonomy'=>'bc_room','hide_empty'=>false)) as $room){echo '<option value="'.(int)$room->term_id.'" '.selected($selected_room,$room->term_id,false).'>'.esc_html($room->name).'</option>';}echo '</select>';
        } elseif ($field['kind'] === 'choices') {
            foreach ($field['options'] as $option=>$label) {
                echo '<label style="display:block"><input type="checkbox" name="' . esc_attr($name) . '[]" value="' . esc_attr($option) . '" ' . checked(in_array($option,(array)$value,true),true,false) . '> ' . esc_html($label) . '</label>';
            }
            $unknown=array_diff((array)$value,array_keys($field['options']));
            if ($unknown) { echo '<span class="description">Categorie non più configurate (selezionare quelle attuali): ' . esc_html(implode(', ',$unknown)) . '</span>'; }
        } elseif ($field['kind'] === 'bool') {
            echo '<input type="checkbox" id="' . esc_attr($dom_id) . '" name="' . esc_attr($name) . '" value="1" ' . checked((bool) $value, true, false) . '>';
        } elseif ($field['kind'] === 'lines') {
            if ($key === 'goals') {
                echo '<span class="description">Valori del questionario: ' . esc_html(implode(', ',array_column(bracelli_club_explorer_settings()['goals'],'label'))) . '. Sono accettati anche gli ID stabili mostrati in Explorer intelligente.</span>';
            }
            echo '<textarea rows="4" class="widefat" id="' . esc_attr($dom_id) . '" name="' . esc_attr($name) . '">' . esc_textarea(implode("\n", (array) $value)) . '</textarea>';
        } elseif ($field['kind'] === 'select' || in_array($field['kind'], array('relation','relations'), true)) {
            $many = $field['kind'] === 'relations'; $options = $field['options'] ?? array('' => '— Seleziona —');
            if (isset($field['target'])) {
                foreach (get_posts(array('post_type' => $field['target'], 'post_status' => array('publish','draft','pending','private','future'), 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC')) as $item) {
                    $options[$item->ID] = $item->post_title . ' [' . $item->post_status . ']';
                }
            }
            echo '<select class="widefat" id="' . esc_attr($dom_id) . '" name="' . esc_attr($name . ($many ? '[]' : '')) . '"' . ($many ? ' multiple size="6"' : '') . '>';
            foreach ($options as $id => $label) {
                $chosen = $many ? in_array((string) $id, array_map('strval', (array) $value), true) : (string) $id === (string) $value;
                echo '<option value="' . esc_attr($id) . '" ' . selected($chosen, true, false) . '>' . esc_html($label) . '</option>';
            }
            echo '</select>';
        } else {
            $media = strpos($field['kind'], 'media_') === 0;
            $display = is_array($value) ? implode(',', $value) : $value;
            echo '<input class="widefat" type="' . ($field['kind'] === 'time' ? 'time' : 'text') . '" id="' . esc_attr($dom_id) . '" name="' . esc_attr($name) . '" value="' . esc_attr($display) . '">';
            if ($media) {
                echo '<button type="button" class="button bc-media" data-input="' . esc_attr($dom_id) . '" data-media="' . ($field['kind'] === 'media_video' ? 'video' : 'image') . '" data-multiple="' . ($field['kind'] === 'media_images' ? '1' : '0') . '">Seleziona / carica dalla libreria</button> <span class="description">ID media; lascia vuoto per rimuovere.</span>';
            }
        }
        echo '</p>';
    }
    if($post->post_type==='bc_slot'){
        echo '<p><a href="'.esc_url(admin_url('edit-tags.php?taxonomy=bc_room&post_type=bc_course')).'">Gestisci sale condivise</a></p>';
        if(bracelli_can('override_schedule')){echo '<fieldset><legend>Eccezione autorizzata alle sovrapposizioni</legend><label><input type="checkbox" name="bc_override" value="1"> Confermo un’eventuale sovrapposizione legittima</label><p><label for="bc-override-reason">Motivazione (10–500 caratteri, senza dati personali non necessari)</label><textarea id="bc-override-reason" class="widefat" name="bc_override_reason" maxlength="500">'.esc_textarea($pending['__override_reason']??'').'</textarea></p></fieldset>';}
        $exception=get_post_meta($post->ID,'_bc_overlap_exception',true);if($exception){echo '<p>Eccezione precedente: '.esc_html($exception['reason']).' · operatore #'.(int)$exception['actor'].'</p>';}
    }
    if ($post->post_type === 'bc_instructor') {
        echo '<h3>Corsi collegati (aggiornati automaticamente)</h3><ul>';
        foreach (get_posts(array('post_type' => 'bc_course', 'post_status' => array('publish','draft','pending','private','future'), 'numberposts' => -1)) as $course) {
            if (in_array($post->ID, array_map('intval', (array) bracelli_club_meta($course->ID, 'instructors', array())), true)) {
                echo '<li><a href="' . esc_url(get_edit_post_link($course->ID)) . '">' . esc_html($course->post_title) . '</a></li>';
            }
        }
        echo '</ul>';
    }
}
function bracelli_club_admin_assets($hook) {
    $screen = get_current_screen();
    if (!$screen || !isset(bracelli_club_types()[$screen->post_type]) || !in_array($hook, array('post.php','post-new.php'), true)) { return; }
    wp_enqueue_media();
    wp_enqueue_script('bracelli-club-admin', plugins_url('assets/admin.js', dirname(__DIR__) . '/bracelli-club.php'), array('jquery','media-views'), '0.3.0', true);
}
function bracelli_club_save_catalog($id, $post) {
    static $saving = false;
    if ($saving || !isset(bracelli_club_types()[$post->post_type]) || wp_is_post_revision($id) || wp_is_post_autosave($id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) { return; }
    if (!isset($_POST['bc_nonce']) || !is_string($_POST['bc_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['bc_nonce'])), 'bc_save_' . $id) || !bracelli_can('manage_content') || !current_user_can('edit_post', $id)) { return; }
    $input = isset($_POST['bc']) && is_array($_POST['bc']) ? wp_unslash($_POST['bc']) : array();
    $calendarLock=false;$lockName='';
    if($post->post_type==='bc_slot'){global $wpdb;$lockName='bc_schedule_'.substr(hash('sha256',$wpdb->prefix),0,40);$calendarLock=(string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,2)',$lockName))==='1';}
    try {
    $clean = $post->post_type==='bc_slot'&&!$calendarLock ? new WP_Error('bc_busy','Calendario in aggiornamento: riprovare tra pochi secondi.') : bracelli_club_validate($post->post_type, $input);
    // Changing an instructor assignment must not silently invalidate existing slots.
    if (!is_wp_error($clean) && $post->post_type === 'bc_course') {
        foreach (get_posts(array('post_type'=>'bc_slot','post_status'=>array('publish','draft','pending','private','future'),'numberposts'=>-1,'meta_key'=>'_bc_course','meta_value'=>$id)) as $slot) {
            $instructor = (int) bracelli_club_meta($slot->ID, 'instructor');
            if ($instructor && !in_array($instructor, $clean['instructors'], true)) {
                $clean = new WP_Error('bc_used_instructor', 'Istruttore usato in un orario: modifica prima gli orari collegati.'); break;
            }
        }
    }
    if (!is_wp_error($clean) && $post->post_type === 'bc_slot') {
        foreach (get_posts(array('post_type'=>'bc_slot','post_status'=>array('publish','draft','pending','private','future'),'numberposts'=>-1,'post__not_in'=>array($id),'meta_key'=>'_bc_course','meta_value'=>$clean['course'])) as $other) {
            if ((int) bracelli_club_meta($other->ID,'day') === (int) $clean['day'] && bracelli_club_meta($other->ID,'start') === $clean['start'] && bracelli_club_meta($other->ID,'end') === $clean['end']) {
                $clean = new WP_Error('bc_duplicate_slot', 'Esiste già questo orario per lo stesso corso. Modifica quello esistente.'); break;
            }
        }
    }
    $exception=array();
    if(!is_wp_error($clean)&&$post->post_type==='bc_slot'){
        $exception=bracelli_schedule_check($id,$clean,isset($_POST['bc_override'])&&$_POST['bc_override']==='1',isset($_POST['bc_override_reason'])?wp_unslash($_POST['bc_override_reason']):'');
        if(is_wp_error($exception)){$clean=$exception;}
    }
    if (is_wp_error($clean)) {
        $pending=array();foreach(bracelli_club_schema($post->post_type) as $key=>$field){if($field['kind']==='bool'){$pending[$key]=!empty($input[$key])?'1':'';}elseif(isset($input[$key])){if(is_scalar($input[$key])){$pending[$key]=sanitize_textarea_field((string)$input[$key]);}elseif(is_array($input[$key])){$pending[$key]=array_map('sanitize_text_field',array_filter($input[$key],'is_scalar'));}}}
        $pending['__override_reason']=isset($_POST['bc_override_reason'])&&is_string($_POST['bc_override_reason'])?sanitize_textarea_field(wp_unslash($_POST['bc_override_reason'])):'';
        set_transient('bc_pending_'.get_current_user_id().'_'.$id,$pending,120);
        set_transient('bc_error_' . get_current_user_id() . '_' . $id, $clean->get_error_message(), 120);
        // Keep previous field values. A newly published invalid record must not leak.
        $saving = true;
        if ($post->post_status === 'publish') { wp_update_post(array('ID' => $id, 'post_status' => 'draft')); }
        $saving = false; return;
    }
    delete_transient('bc_pending_'.get_current_user_id().'_'.$id);
    foreach ($clean as $key => $value) {if($key==='room_id'){wp_set_object_terms($id,$value?array((int)$value):array(),'bc_room',false);}else{update_post_meta($id, '_bc_' . $key, $value);}}
    bracelli_admin_audit('content_update',1,$id);
    if($post->post_type==='bc_slot'){if($exception){update_post_meta($id,'_bc_overlap_exception',$exception);bracelli_admin_audit('schedule_override',1,$id);}else{delete_post_meta($id,'_bc_overlap_exception');}}

    } finally {if($calendarLock){$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lockName));}}
}
function bracelli_club_admin_notice() {
    $id = isset($_GET['post']) ? absint($_GET['post']) : 0;
    $key = 'bc_error_' . get_current_user_id() . '_' . $id;
    $message = get_transient($key);
    if ($message) { delete_transient($key); echo '<div class="notice notice-error"><p>' . esc_html($message . ' Dati Bracelli non salvati; verifica i campi prima di pubblicare.') . '</p></div>'; }
}
function bracelli_club_slot_columns($columns) {
    return array_merge(array_slice($columns, 0, 2, true), array('bc_day'=>'Giorno / ora','bc_course'=>'Corso','bc_room'=>'Sala','bc_instructor'=>'Istruttore','bc_state'=>'Stato'), array_slice($columns, 2, null, true));
}
function bracelli_club_slot_column($column, $id) {
    if ($column === 'bc_day') { $days = bracelli_club_schema('bc_slot')['day']['options']; echo esc_html(($days[bracelli_club_meta($id,'day')] ?? '—') . ' ' . bracelli_club_meta($id,'start') . '–' . bracelli_club_meta($id,'end')); }
    if ($column === 'bc_course' || $column === 'bc_instructor') { $ref = (int) bracelli_club_meta($id, substr($column, 3)); echo $ref ? esc_html(get_the_title($ref)) : '—'; }
    if ($column === 'bc_room') { echo esc_html(bracelli_room_name($id) ?: bracelli_room_name((int) bracelli_club_meta($id,'course'))); }
    if ($column === 'bc_state') {
        static $graph = null;
        if ($graph === null) { $graph = bracelli_club_catalog(); }
        $visible = in_array($id, array_column($graph['schedule'], 'id'), true);
        echo bracelli_club_meta($id,'suspended') ? 'Sospeso' : ($visible ? 'Visibile' : 'Non pubblico / collegamenti da verificare');
    }
}
function bracelli_club_slot_filters($type) {
    if ($type !== 'bc_slot') { return; }
    $fields = array('day' => bracelli_club_schema('bc_slot')['day']['options'], 'course' => array(), 'instructor' => array(), 'suspended' => array('0'=>'Non sospesi','1'=>'Sospesi'));
    foreach (get_posts(array('post_type'=>'bc_course','post_status'=>array('publish','draft','pending','private','future'),'numberposts'=>-1)) as $course) { $fields['course'][$course->ID] = $course->post_title; }
    foreach (get_posts(array('post_type'=>'bc_instructor','post_status'=>array('publish','draft','pending','private','future'),'numberposts'=>-1)) as $instructor) { $fields['instructor'][$instructor->ID] = $instructor->post_title; }
    foreach ($fields as $key => $options) {
        $selected = isset($_GET['bc_' . $key]) && is_scalar($_GET['bc_' . $key]) ? sanitize_text_field(wp_unslash($_GET['bc_' . $key])) : '';
        echo '<label class="screen-reader-text" for="filter-bc-' . esc_attr($key) . '">' . esc_html(bracelli_club_schema('bc_slot')[$key]['label']) . '</label><select id="filter-bc-' . esc_attr($key) . '" name="bc_' . esc_attr($key) . '"><option value="">' . esc_html(bracelli_club_schema('bc_slot')[$key]['label']) . '</option>';
        foreach ($options as $value=>$label) { echo '<option value="' . esc_attr($value) . '" ' . selected((string)$value,$selected,false) . '>' . esc_html($label) . '</option>'; }
        echo '</select>';
    }
}
function bracelli_club_filter_slots($query) {
    if (!is_admin() || !$query->is_main_query() || $query->get('post_type') !== 'bc_slot') { return; }
    $meta = array('relation'=>'AND');
    foreach (array('day','course','instructor','suspended') as $key) {
        $value = $_GET['bc_' . $key] ?? '';
        if (is_scalar($value) && $value !== '') { $meta[] = array('key'=>'_bc_' . $key,'value'=>absint($value),'compare'=>'=','type'=>'NUMERIC'); }
    }
    if (count($meta)>1) { $query->set('meta_query', $meta); }
}
