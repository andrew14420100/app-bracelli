<?php
if (!defined('ABSPATH')) { exit; }
function bracelli_trial_table($limits=false) { global $wpdb;return $wpdb->prefix.($limits?'bc_trial_limits':'bc_trial_requests'); }
function bracelli_trial_db($callback) { global $wpdb;$previous=$wpdb->suppress_errors(true);try{return $callback();}finally{$wpdb->suppress_errors($previous);} }
function bracelli_trial_install() {
    global $wpdb;
    require_once ABSPATH.'wp-admin/includes/upgrade.php';
    $table=bracelli_trial_table();$limits=bracelli_trial_table(true);$charset=$wpdb->get_charset_collate();
    dbDelta("CREATE TABLE $table (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        created_at datetime NOT NULL,
        updated_at datetime NOT NULL,
        expires_at datetime NOT NULL,
        first_name varchar(80) NOT NULL,
        last_name varchar(80) NOT NULL,
        email varchar(254) NOT NULL,
        phone varchar(24) NOT NULL,
        discipline_id bigint(20) unsigned NOT NULL,
        course_id bigint(20) unsigned NOT NULL DEFAULT 0,
        discipline_name varchar(200) NOT NULL,
        course_name varchar(200) NOT NULL DEFAULT '',
        age_band varchar(160) NOT NULL DEFAULT '',
        preferred_day tinyint unsigned NOT NULL DEFAULT 0,
        message text NOT NULL,
        privacy_version char(64) NOT NULL,
        privacy_notice text NOT NULL,
        status varchar(24) NOT NULL DEFAULT 'new',
        notes text NOT NULL,
        history longtext NOT NULL,
        submission_hash char(64) NOT NULL,
        fingerprint char(64) NOT NULL,
        mail_status varchar(16) NOT NULL DEFAULT 'pending',
        mail_attempts int unsigned NOT NULL DEFAULT 0,
        mail_error varchar(32) NOT NULL DEFAULT '',
        last_mail_at datetime DEFAULT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY submission_hash (submission_hash),
        KEY fingerprint (fingerprint),
        KEY email (email(191)),
        KEY created_at (created_at),
        KEY expires_at (expires_at),
        KEY status (status)
    ) $charset;");
    dbDelta("CREATE TABLE $limits (
        guard_key char(64) NOT NULL,
        hits int unsigned NOT NULL DEFAULT 0,
        expires_at datetime NOT NULL,
        PRIMARY KEY  (guard_key),
        KEY expires_at (expires_at)
    ) $charset;");
    $exists=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($table)));
    if ($exists!==$table) { return new WP_Error('bc_trial_schema','Archivio non disponibile.'); }
    update_option('bc_trial_schema_version','1',false);
    $admin=get_role('administrator');if($admin){$admin->add_cap('manage_bracelli_trials');}
    if(!wp_next_scheduled('bc_trial_cleanup')){wp_schedule_event(time()+HOUR_IN_SECONDS,'daily','bc_trial_cleanup');}
    return true;
}
function bracelli_trial_upgrade() { if(!current_user_can('manage_options')){return;}if(get_option('bc_trial_schema_version')!=='1'){bracelli_trial_install();}elseif(!wp_next_scheduled('bc_trial_cleanup')){wp_schedule_event(time()+HOUR_IN_SECONDS,'daily','bc_trial_cleanup');} }
function bracelli_trial_deactivate() { wp_clear_scheduled_hook('bc_trial_cleanup'); }
function bracelli_trial_digest($value) { return hash_hmac('sha256',$value,wp_salt('auth')); }
function bracelli_trial_ip() { $ip=$_SERVER['REMOTE_ADDR'] ?? '';return is_string($ip) && filter_var($ip,FILTER_VALIDATE_IP) ? $ip : 'unknown'; }
function bracelli_trial_rate($kind,$identity,$limit,$window) {
    global $wpdb;$table=bracelli_trial_table(true);$bucket=(int)floor(time()/$window);$key=bracelli_trial_digest($kind.'|'.$identity.'|'.$bucket);
    $expires=gmdate('Y-m-d H:i:s',($bucket+1)*$window);
    return bracelli_trial_db(function() use($wpdb,$table,$key,$expires,$limit){
        $written=$wpdb->query($wpdb->prepare("INSERT INTO $table (guard_key,hits,expires_at) VALUES (%s,1,%s) ON DUPLICATE KEY UPDATE hits=hits+1",$key,$expires));
        if($written===false){return new WP_Error('bc_trial_unavailable','Servizio temporaneamente non disponibile.',array('status'=>503));}
        $hits=(int)$wpdb->get_var($wpdb->prepare("SELECT hits FROM $table WHERE guard_key=%s",$key));
        return $hits<=$limit ? true : new WP_Error('bc_trial_rate','Troppi tentativi. Attendi qualche minuto e riprova.',array('status'=>429));
    });
}
function bracelli_trial_cleanup() {
    global $wpdb;$table=bracelli_trial_table();$limits=bracelli_trial_table(true);$now=current_time('mysql',true);
    $cutoff=gmdate('Y-m-d H:i:s',time()-bracelli_trial_settings()['retention_days']*DAY_IN_SECONDS);
    bracelli_trial_db(function()use($wpdb,$table,$limits,$now,$cutoff){$wpdb->query($wpdb->prepare("DELETE FROM $table WHERE expires_at<=%s OR created_at<%s",$now,$cutoff));$wpdb->query($wpdb->prepare("DELETE FROM $limits WHERE expires_at<=%s",$now));});
}
function bracelli_trial_get($id) {
    global $wpdb;$table=bracelli_trial_table();return bracelli_trial_db(function()use($wpdb,$table,$id){return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d",$id),ARRAY_A);});
}
function bracelli_trial_states() { return array('new'=>'Nuova','contact'=>'Da contattare','waiting'=>'In attesa','confirmed'=>'Confermata','completed'=>'Completata','cancelled'=>'Annullata'); }
function bracelli_trial_update_locked($id,$status,$notes,$nonce,$audit=true,$revision='') {
    global $wpdb;
    if((!bracelli_can('edit_trials') || !bracelli_can('view_trials')) || !is_string($nonce) || !wp_verify_nonce($nonce,'bc_trial_'.$id)){return new WP_Error('bc_forbidden','Operazione non autorizzata.');}
    if(!is_string($status) || !isset(bracelli_trial_states()[$status]) || !is_string($notes) || mb_strlen($notes)>4000){return new WP_Error('bc_trial_invalid','Stato o note non validi.');}
    $table=bracelli_trial_table();$row=bracelli_trial_get($id);if(!$row){return new WP_Error('bc_trial_missing','Richiesta non disponibile.');}
    if($revision!==''&&!hash_equals(bracelli_trial_revision($row),$revision)){return new WP_Error('bc_stale','La richiesta è stata modificata da un altro operatore. Ricaricare i dettagli prima di salvare.');}
    $notes=sanitize_textarea_field($notes);$history=json_decode($row['history'],true) ?: array();$now=current_time('mysql',true);
    if($row['status']!==$status){$history[]=array('at'=>$now,'actor'=>get_current_user_id(),'event'=>'status','from'=>$row['status'],'to'=>$status);}
    if($row['notes']!==$notes){$history[]=array('at'=>$now,'actor'=>get_current_user_id(),'event'=>'notes');}
    $result=bracelli_trial_db(function()use($wpdb,$table,$id,$status,$notes,$history,$now){return $wpdb->update($table,array('status'=>$status,'notes'=>$notes,'history'=>wp_json_encode(array_slice($history,-200)),'updated_at'=>$now),array('id'=>$id));});
    if($result!==false && $audit){bracelli_admin_audit('request_update',1,$id);}
    return $result===false ? new WP_Error('bc_trial_storage','Aggiornamento temporaneamente non disponibile.') : true;
}
function bracelli_trial_deliver($id) {
    global $wpdb;$table=bracelli_trial_table();$row=bracelli_trial_get($id);if(!$row){return false;}
    $recipient=bracelli_trial_recipients(bracelli_trial_settings()['notification_email']);$sent=false;
    if($recipient){
        $body="È stata ricevuta una richiesta di lezione di prova.\n\nDisciplina: ".$row['discipline_name'];
        if($row['course_name']!==''){$body.="\nCorso: ".$row['course_name'];}
        $body.="\nRicevuta (UTC): ".$row['created_at']."\n\nConsulta i dettagli nel pannello riservato:\n".admin_url('admin.php?page=bc-trials&request='.(int)$id)."\n\nNessun appuntamento o posto è stato assegnato automaticamente.";
        try{$sent=(bool)wp_mail($recipient,'Bracelli Club — Nuova richiesta di prova',$body,array('Content-Type: text/plain; charset=UTF-8'));}catch(Throwable $error){$sent=false;}
    }
    // No exception, address, submitted message or transport ErrorInfo is logged.
    bracelli_trial_db(function()use($wpdb,$table,$id,$sent){return $wpdb->query($wpdb->prepare("UPDATE $table SET mail_status=%s,mail_error=%s,mail_attempts=mail_attempts+1,last_mail_at=%s WHERE id=%d",$sent?'sent':'failed',$sent?'':'transport_failure',current_time('mysql',true),$id));});
    return $sent;
}

function bracelli_trial_notify($id) {
    global $wpdb;$lock='bc_notify_'.substr(hash('sha256',bracelli_trial_table().'|'.$id),0,48);
    if((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock))!=='1'){return false;}
    try{$row=bracelli_trial_get($id);if(!$row){return false;}if($row['mail_status']==='sent'){return true;}if($row['last_mail_at'] && strtotime($row['last_mail_at'].' UTC')>time()-60){return false;}return bracelli_trial_deliver($id);}
    finally{$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));}
}
function bracelli_trial_resend($id,$nonce) {
    if(!bracelli_can('edit_trials')||!bracelli_can('view_trials')||!is_string($nonce)||!wp_verify_nonce($nonce,'bc_trial_'.$id)){return new WP_Error('bc_forbidden','Reinvio non autorizzato.');}
    $row=bracelli_trial_get($id);if(!$row||$row['mail_status']!=='failed'){return new WP_Error('bc_mail','Il reinvio è disponibile solo per notifiche fallite.');}
    if($row['last_mail_at']&&strtotime($row['last_mail_at'].' UTC')>time()-60){return new WP_Error('bc_mail_wait','Attendere almeno 60 secondi dal tentativo precedente.');}
    $result=bracelli_trial_notify($id);bracelli_admin_audit('mail_retry',1,$id);return $result;
}

function bracelli_trial_revision($row){return hash('sha256',$row['updated_at'].'|'.$row['status'].'|'.$row['notes']);}
function bracelli_trial_lock_name($id){return 'bc_edit_'.substr(hash('sha256',bracelli_trial_table().'|'.(int)$id),0,48);}
function bracelli_trial_lock($id){global $wpdb;return (string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,2)',bracelli_trial_lock_name($id)))==='1';}
function bracelli_trial_unlock($id){global $wpdb;$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',bracelli_trial_lock_name($id)));}
function bracelli_trial_update($id,$status,$notes,$nonce,$audit=true,$revision=''){
    if(!bracelli_can('edit_trials')||!bracelli_can('view_trials')||!is_string($nonce)||!wp_verify_nonce($nonce,'bc_trial_'.$id)){return new WP_Error('bc_forbidden','Operazione non autorizzata.');}
    if(!bracelli_trial_lock($id)){return new WP_Error('bc_busy','Richiesta in aggiornamento: riprovare.');}
    try{return bracelli_trial_update_locked($id,$status,$notes,$nonce,$audit,$revision);}finally{bracelli_trial_unlock($id);}
}
