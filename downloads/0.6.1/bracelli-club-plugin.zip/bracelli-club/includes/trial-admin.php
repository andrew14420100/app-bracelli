<?php
if (!defined('ABSPATH')) { exit; }
function bracelli_trial_menu() {
    add_submenu_page('bracelli-club','Richieste di prova','Richieste di prova','bracelli_view_trials','bc-trials','bracelli_trial_admin_page');
    add_submenu_page('bracelli-club','Contatti e richieste','Contatti e richieste','bracelli_manage_settings','bc-trial-settings','bracelli_trial_settings_page');
}
function bracelli_trial_settings_page() {
    if(!bracelli_can('manage_settings')){wp_die('Operazione non autorizzata.');}
    $s=bracelli_trial_settings();
    echo '<div class="wrap"><h1>Contatti e richieste</h1><p>Inserire soltanto dati effettivi del centro. Il modulo è disabilitato finché non sono configurati email destinataria e informativa. Nessun indirizzo di destinazione viene presunto.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="bc_trial_settings">';
    wp_nonce_field('bc_trial_settings','bc_nonce');
    echo '<p><label><input type="checkbox" name="settings[enabled]" value="1" '.checked($s['enabled'],true,false).'> Abilita richieste online</label></p>';
    $labels=array('notification_email'=>'Email privata di notifica alla segreteria','phone'=>'Telefono pubblico','whatsapp'=>'Numero WhatsApp internazionale (con +)','email'=>'Email pubblica','address'=>'Indirizzo del centro','directions'=>'URL indicazioni stradali (solo link, nessuna mappa incorporata)','office_hours'=>'Orari della segreteria','controller'=>'Titolare del trattamento (identità effettiva)','privacy_email'=>'Email per esercitare i diritti privacy','legal_basis'=>'Base giuridica effettiva del trattamento','processors'=>'Destinatari/responsabili, hosting/email e trasferimenti effettivi','privacy_extra'=>'Ulteriori dettagli dell’informativa','privacy_url'=>'URL informativa completa (facoltativo)','retention_days'=>'Conservazione massima in giorni (7–365)');
    foreach($labels as $key=>$label){
        echo '<p><label for="bc-setting-'.esc_attr($key).'"><strong>'.esc_html($label).'</strong></label><br>';
        if(in_array($key,array('office_hours','legal_basis','processors','privacy_extra','address'),true)){echo '<textarea id="bc-setting-'.esc_attr($key).'" class="large-text" rows="3" name="settings['.esc_attr($key).']">'.esc_textarea($s[$key]).'</textarea>';}
        else{echo '<input id="bc-setting-'.esc_attr($key).'" class="regular-text" type="'.($key==='retention_days'?'number':'text').'" name="settings['.esc_attr($key).']" value="'.esc_attr($s[$key]).'">';}echo '</p>';
    }
    submit_button('Salva contatti e impostazioni');echo '</form><h2>Anteprima informativa</h2><pre style="white-space:pre-wrap">'.esc_html(bracelli_trial_notice($s)).'</pre><p>L’amministratore deve verificare che titolare, base giuridica, fornitori e trasferimenti descrivano il trattamento effettivo prima dell’abilitazione. Si raccoglie una presa visione, non un consenso promozionale.</p><p>Le notifiche usano wp_mail e il sistema email configurato in WordPress. “Inviata al trasporto” non garantisce la consegna alla casella. Nei dettagli è disponibile il reinvio controllato in caso di problemi.</p><p>Pulizia automatica giornaliera tramite WP-Cron; configurare un cron reale se il sito non ha traffico. L’installazione crea un archivio privato e la capability manage_bracelli_trials, assegnata inizialmente solo agli amministratori.</p></div>';
}
function bracelli_trial_save_settings_handler() {
    $input=isset($_POST['settings']) && is_array($_POST['settings']) ? wp_unslash($_POST['settings']) : array();
    $result=bracelli_trial_apply_settings($input,isset($_POST['bc_nonce'])?wp_unslash($_POST['bc_nonce']):'');
    if(is_wp_error($result)){wp_die(esc_html($result->get_error_message()),'Impostazioni',array('response'=>403));}
    bracelli_admin_flash('Contatti e impostazioni delle richieste salvati.');
    wp_safe_redirect(admin_url('admin.php?page=bc-trial-settings'));exit;
}
function bracelli_trial_search($search='',$status='',$page=1) {
    $result=bracelli_requests_query(array('search'=>$search,'status'=>$status,'page'=>$page),21);return is_wp_error($result)?$result:$result['rows'];
}
function bracelli_trial_admin_page() {
    if(!bracelli_can('view_trials')){wp_die('Operazione non autorizzata.');}
    echo '<div class="wrap"><h1>Richieste di prova</h1><p>La ricezione non prenota posti. La conferma è una decisione manuale della segreteria.</p>';
    $id=isset($_GET['request'])?absint($_GET['request']):0;
    if($id){
        $row=bracelli_trial_get($id);if(!$row){echo '<p>Richiesta non disponibile.</p></div>';return;}
        echo '<p><a href="'.esc_url(admin_url('admin.php?page=bc-trials')).'">← Elenco richieste</a></p><h2>Richiesta #'.(int)$id.'</h2><dl>';
        $fields=array('created_at'=>'Ricevuta (UTC)','expires_at'=>'Scadenza conservazione (UTC)','first_name'=>'Nome referente','last_name'=>'Cognome referente','email'=>'Email','phone'=>'Telefono','discipline_name'=>'Disciplina','course_name'=>'Corso','age_band'=>'Fascia d’età','preferred_day'=>'Giorno preferito (1=lunedì, 7=domenica; 0=nessuna preferenza)','message'=>'Messaggio','privacy_version'=>'Versione informativa','mail_status'=>'Notifica: sent=accettata dal trasporto, failed=problema tecnico','mail_attempts'=>'Tentativi di notifica','mail_error'=>'Codice tecnico');
        foreach($fields as $key=>$label){echo '<dt><strong>'.esc_html($label).'</strong></dt><dd style="white-space:pre-wrap">'.esc_html($row[$key]).'</dd>';}
        echo '<dt><strong>Note interne</strong></dt><dd>'.esc_html($row['notes']).'</dd></dl><details><summary>Informativa presa in visione alla ricezione</summary><p style="white-space:pre-wrap">'.esc_html($row['privacy_notice']).'</p></details>';
        if(bracelli_can('edit_trials')){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="bc_trial_update"><input type="hidden" name="request_id" value="'.(int)$id.'">';
        wp_nonce_field('bc_trial_'.$id,'bc_nonce');echo '<input type="hidden" name="revision" value="'.esc_attr(bracelli_trial_revision($row)).'">';
        echo '<p><label>Stato <select name="status">';foreach(bracelli_trial_states() as $value=>$label){echo '<option value="'.esc_attr($value).'" '.selected($row['status'],$value,false).'>'.esc_html($label).'</option>';}echo '</select></label></p><p><label for="bc-trial-notes">Note interne (solo quanto necessario)</label><br><textarea id="bc-trial-notes" class="large-text" rows="5" maxlength="4000" name="notes">'.esc_textarea($row['notes']).'</textarea></p>';
        submit_button('Salva stato e note');if($row['mail_status']==='failed'){echo '<button class="button" name="resend" value="1" type="submit">Riprova notifica email</button>';}echo '</form>';}echo '<h2>Storico essenziale</h2><ul>';
        foreach((array)json_decode($row['history'],true) as $event){$text=$event['at'].' · '.$event['event'];if(isset($event['from'],$event['to'])){$text.=' · '.(bracelli_trial_states()[$event['from']] ?? $event['from']).' → '.(bracelli_trial_states()[$event['to']] ?? $event['to']);}$text.=' · operatore #'.(int)$event['actor'];echo '<li>'.esc_html($text).'</li>';}
        echo '</ul></div>';return;
    }
    bracelli_trials_list();echo '</div>';
}
function bracelli_trial_update_handler() {
    $id=absint($_POST['request_id'] ?? 0);$nonce=isset($_POST['bc_nonce'])?wp_unslash($_POST['bc_nonce']):'';
    $status=isset($_POST['status'])?wp_unslash($_POST['status']):'';$notes=isset($_POST['notes'])?wp_unslash($_POST['notes']):'';
    if(!isset($_POST['revision'])||!is_string($_POST['revision'])){wp_die('Ricaricare la scheda prima di salvare.','',array('response'=>409));}
    $result=bracelli_trial_update($id,$status,$notes,$nonce,true,wp_unslash($_POST['revision']));
    if(is_wp_error($result)){wp_die(esc_html($result->get_error_message()),'Richiesta',array('response'=>403));}
    if(isset($_POST['resend']) && $_POST['resend']==='1'){
        $retry=bracelli_trial_resend($id,$nonce);if(is_wp_error($retry)){wp_die(esc_html($retry->get_error_message()),'',array('response'=>409));}
    }
    bracelli_admin_flash('Stato e note salvati.');
    wp_safe_redirect(admin_url('admin.php?page=bc-trials&request='.$id));exit;
}
