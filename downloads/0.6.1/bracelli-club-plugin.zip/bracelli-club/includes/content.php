<?php
if (!defined('ABSPATH')) { exit; }
function bracelli_club_register_content() {
    foreach (array('bc_news' => 'Notizie Club', 'bc_event' => 'Eventi Club') as $type => $label) {
        register_post_type($type, array(
            'label' => $label,
            'public' => false,
            'show_ui' => true,
            'show_in_rest' => false,
            'show_in_menu' => 'bracelli-club',
            'menu_icon' => 'dashicons-groups',
            'supports' => array('title', 'editor', 'excerpt'),
            'capability_type' => 'post',
            'map_meta_cap' => true, 'capabilities'=>bracelli_content_caps(),
            'rewrite' => false,
            'has_archive' => false,
        ));
    }
}
