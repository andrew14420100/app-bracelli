<?php
if (!defined('ABSPATH')) { exit; }
function bracelli_club_public_posts($type) {
    return get_posts(array('post_type'=>$type,'post_status'=>'publish','has_password'=>false,'numberposts'=>-1,'orderby'=>array('menu_order'=>'ASC','title'=>'ASC','ID'=>'ASC'),'suppress_filters'=>false));
}
function bracelli_club_public_text($text) {
    // Expand neither shortcodes nor embeds from existing site plugins.
    return html_entity_decode(wp_strip_all_tags(strip_shortcodes($text)), ENT_QUOTES, 'UTF-8');
}
function bracelli_club_public_base($post) {
    return array('id'=>(int)$post->ID,'name'=>bracelli_club_public_text($post->post_title),'description'=>bracelli_club_public_text($post->post_content),'summary'=>bracelli_club_public_text($post->post_excerpt),'order'=>(int)$post->menu_order);
}
function bracelli_club_media_url($id, $kind) {
    if (!$id || ($kind === 'image' ? !wp_attachment_is_image($id) : strpos((string)get_post_mime_type($id),'video/') !== 0)) { return ''; }
    // Use an existing WordPress derivative when available; never regenerate or alter media.
    $url=$kind==='image' ? wp_get_attachment_image_url($id,'large') : wp_get_attachment_url($id);
    return esc_url_raw($url ?: '', array('http','https'));
}
function bracelli_club_catalog() {
    $disciplines = $instructors = $courses = $schedule = array();
    foreach (bracelli_club_public_posts('bc_discipline') as $post) {
        if (bracelli_club_meta($post->ID,'hidden')) { continue; }
        $id = $post->ID; $item = bracelli_club_public_base($post);
        $terms = wp_get_post_terms($id,'bc_category',array('fields'=>'names'));
        $item['categories'] = is_wp_error($terms) ? array() : array_map('bracelli_club_public_text',$terms);
        foreach (array('ages','benefits') as $key) { $item[$key] = array_map('sanitize_text_field',(array)bracelli_club_meta($id,$key,array())); }
        $item['photos'] = array_values(array_filter(array_map(function($photo){return bracelli_club_media_url(absint($photo),'image');},(array)bracelli_club_meta($id,'photos',array()))));
        $item['video'] = bracelli_club_media_url((int)bracelli_club_meta($id,'video'),'video');
        $item['features'] = array();
        foreach (array('intensity','environment','format') as $key) { $item['features'][$key] = sanitize_text_field(bracelli_club_meta($id,$key)); }
        $item['features']['preferences'] = array_values(array_map('sanitize_text_field',(array)bracelli_club_meta($id,'preferences',array())));
        $item['features']['goals'] = array_map('sanitize_text_field',(array)bracelli_club_meta($id,'goals',array()));
        $disciplines[$id] = $item;
    }
    foreach (bracelli_club_public_posts('bc_instructor') as $post) {
        $item = bracelli_club_public_base($post); $item['photo'] = bracelli_club_media_url((int)bracelli_club_meta($post->ID,'photo'),'image');
        $instructors[$post->ID] = $item;
    }
    foreach (bracelli_club_public_posts('bc_course') as $post) {
        $id=$post->ID; $discipline=(int)bracelli_club_meta($id,'discipline');
        if (!bracelli_club_meta($id,'active') || !isset($disciplines[$discipline])) { continue; }
        $item=bracelli_club_public_base($post); $item['disciplineId']=$discipline;
        $item['instructorIds']=array_values(array_filter(array_map('intval',(array)bracelli_club_meta($id,'instructors',array())),function($ref) use ($instructors){return isset($instructors[$ref]);}));
        $item['ageRange']=bracelli_club_explorer_age_range($id);
        $item['age']=sanitize_text_field(bracelli_club_meta($id,'age')); $item['level']=sanitize_text_field(bracelli_club_meta($id,'level','all'));
        $item['room']=sanitize_text_field(bracelli_room_name($id)); $item['trial']=(bool)bracelli_club_meta($id,'trial');
        $courses[$id]=$item;
    }
    foreach (bracelli_club_public_posts('bc_slot') as $post) {
        $id=$post->ID; $course=(int)bracelli_club_meta($id,'course'); $instructor=(int)bracelli_club_meta($id,'instructor');
        if (bracelli_club_meta($id,'suspended') || !isset($courses[$course],$instructors[$instructor]) || !in_array($instructor,$courses[$course]['instructorIds'],true)) { continue; }
        $day=(int)bracelli_club_meta($id,'day'); $start=bracelli_club_meta($id,'start'); $end=bracelli_club_meta($id,'end');
        if ($day<1 || $day>7 || !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D',$start) || !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D',$end) || $end<=$start) { continue; }
        $schedule[]=array('id'=>(int)$id,'courseId'=>$course,'instructorId'=>$instructor,'day'=>$day,'start'=>$start,'end'=>$end,'room'=>sanitize_text_field(bracelli_room_name($id) ?: $courses[$course]['room']));
    }
    usort($schedule,function($a,$b){return array($a['day'],$a['start'],$a['id']) <=> array($b['day'],$b['start'],$b['id']);});
    return array('disciplines'=>array_values($disciplines),'courses'=>array_values($courses),'instructors'=>array_values($instructors),'schedule'=>$schedule,'timezone'=>wp_timezone_string(),'explorer'=>bracelli_club_explorer_settings());
}
function bracelli_club_register_catalog_routes() {
    foreach (array('catalog','disciplines','courses','instructors','schedule') as $resource) {
        register_rest_route('bracelli-club/v1','/' . $resource,array(
            'methods'=>WP_REST_Server::READABLE,'permission_callback'=>'__return_true',
            'callback'=>function() use ($resource){$catalog=bracelli_club_catalog();$response=rest_ensure_response($resource==='catalog'?$catalog:$catalog[$resource]);$response->header('Cache-Control','no-store, max-age=0');return $response;},
        ));
    }
    register_rest_route('bracelli-club/v1','/disciplines/(?P<id>\d+)',array(
        'methods'=>WP_REST_Server::READABLE,'permission_callback'=>'__return_true',
        'callback'=>function($request){foreach(bracelli_club_catalog()['disciplines'] as $item){if($item['id']===(int)$request['id']){return rest_ensure_response($item);}}return new WP_Error('bc_not_found','Disciplina non disponibile.',array('status'=>404));},
    ));
}
