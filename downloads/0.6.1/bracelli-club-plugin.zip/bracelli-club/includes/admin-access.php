<?php
if (!defined('ABSPATH')) { exit; }
function bracelli_admin_caps() {
    return array('bracelli_access'=>'Accesso pannello','bracelli_view_trials'=>'Consultazione richieste','bracelli_edit_trials'=>'Modifica richieste','bracelli_manage_content'=>'Gestione contenuti','bracelli_export_trials'=>'Esportazione dati','bracelli_manage_settings'=>'Impostazioni plugin','bracelli_delete_data'=>'Eliminazione dati','bracelli_override_schedule'=>'Eccezioni sovrapposizioni');
}
function bracelli_can($operation) { return current_user_can('bracelli_'.$operation); }
function bracelli_content_caps() {
    $caps=array();foreach(array('edit_posts','edit_others_posts','publish_posts','read_private_posts','edit_private_posts','edit_published_posts','create_posts') as $key){$caps[$key]='bracelli_manage_content';}
    foreach(array('delete_posts','delete_private_posts','delete_published_posts','delete_others_posts') as $key){$caps[$key]='bracelli_delete_data';}
    $caps['edit_post']='bracelli_edit_item';$caps['read_post']='bracelli_read_item';$caps['delete_post']='bracelli_delete_item';
    $caps['read']='read';return $caps;
}
function bracelli_admin_install() {
    $admin=get_role('administrator');if($admin){foreach(bracelli_admin_caps() as $cap=>$label){$admin->add_cap($cap);}}
    if(get_option('bc_admin_version')!=='1'){
        foreach(wp_roles()->roles as $name=>$definition){
            $role=get_role($name);
            if(!empty($definition['capabilities']['edit_others_posts'])){$role->add_cap('bracelli_access');$role->add_cap('bracelli_manage_content');}
            if(!empty($definition['capabilities']['manage_bracelli_trials'])){$role->add_cap('bracelli_access');$role->add_cap('bracelli_view_trials');$role->add_cap('bracelli_edit_trials');}
        }
        foreach(get_users(array('meta_key'=>$GLOBALS['wpdb']->prefix.'capabilities','meta_value'=>'manage_bracelli_trials','meta_compare'=>'LIKE')) as $user){if(array_key_exists('manage_bracelli_trials',$user->caps)){$allowed=user_can($user,'manage_bracelli_trials');foreach(array('bracelli_view_trials','bracelli_edit_trials') as $cap){$user->add_cap($cap,$allowed);}if($allowed){$user->add_cap('bracelli_access');}}}
        foreach(get_users(array('meta_key'=>$GLOBALS['wpdb']->prefix.'capabilities','meta_value'=>'edit_others_posts','meta_compare'=>'LIKE')) as $user){if(array_key_exists('edit_others_posts',$user->caps)&&!user_can($user,'edit_others_posts')){$user->add_cap('bracelli_manage_content',false);}}
        update_option('bc_admin_version','1',false);
    }
    if(!get_role('bracelli_secretary')){add_role('bracelli_secretary','Segreteria Bracelli',array('read'=>true,'bracelli_access'=>true,'bracelli_view_trials'=>true,'bracelli_edit_trials'=>true));}
    bracelli_rooms_register();
    if(!get_option('bc_rooms_migrated')){bracelli_rooms_import();update_option('bc_rooms_migrated',1,false);}
    $user=wp_get_current_user();if($user->exists()){$user->get_role_caps();}
}
function bracelli_admin_upgrade() { if(current_user_can('manage_options')&&get_option('bc_admin_version')!=='1'){bracelli_admin_install();} }
function bracelli_admin_audit($event,$count=1,$object=0) {
    global $wpdb;$lock='bc_audit_'.substr(hash('sha256',$wpdb->prefix),0,35);
    if((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,2)',$lock))!=='1'){return false;}
    try{wp_cache_delete('bc_admin_audit','options');wp_cache_delete('notoptions','options');$log=get_option('bc_admin_audit',array());$log[]=array('at'=>current_time('mysql',true),'actor'=>get_current_user_id(),'event'=>sanitize_key($event),'count'=>(int)$count,'object'=>(int)$object);return update_option('bc_admin_audit',array_slice($log,-200),false);}
    finally{$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));}
}
function bracelli_admin_audit_cleanup(){ $cutoff=time()-30*DAY_IN_SECONDS;update_option('bc_admin_audit',array_values(array_filter((array)get_option('bc_admin_audit',array()),function($row)use($cutoff){return strtotime($row['at'].' UTC')>=$cutoff;})),false); }
function bracelli_permissions_apply($id,$selected,$nonce) {
    if(!current_user_can('manage_options') || !is_string($nonce) || !wp_verify_nonce($nonce,'bc_permissions')){return new WP_Error('bc_forbidden','Operazione non autorizzata.');}
    $user=get_user_by('id',$id);if(!$user || in_array('administrator',$user->roles,true) || is_super_admin($id)){return new WP_Error('bc_permissions','Gestire solo account non amministratori.');}
    if(!is_array($selected)||array_diff($selected,array_keys(bracelli_admin_caps()))){return new WP_Error('bc_permissions','Permessi non validi.');}
    // Explicit false overrides a role grant, without changing global WordPress roles.
    foreach(bracelli_admin_caps() as $cap=>$label){$user->add_cap($cap,in_array($cap,$selected,true));}
    if(array_diff($selected,array('bracelli_access'))){$user->add_cap('bracelli_access');}
    bracelli_admin_audit('permissions',1,$id);return true;
}
function bracelli_permissions_page() {
    if(!current_user_can('manage_options')){wp_die('Operazione non autorizzata.');}
    echo '<div class="wrap"><h1>Permessi Bracelli Club</h1><p>Solo capability del plugin: nessuna concessione di permessi su altri plugin, articoli o impostazioni WordPress. Gli amministratori mantengono accesso completo.</p><form method="get"><input type="hidden" name="page" value="bc-permissions"><label>Account <select name="user_id">';
    $id=absint($_GET['user_id']??0);
    foreach(get_users(array('number'=>200,'orderby'=>'display_name')) as $user){if(in_array('administrator',$user->roles,true)){continue;}echo '<option value="'.(int)$user->ID.'" '.selected($id,$user->ID,false).'>'.esc_html($user->display_name).'</option>';if(!$id){$id=$user->ID;}}
    echo '</select></label> <button class="button">Apri permessi</button></form>';
    $user=get_user_by('id',$id);if($user){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="bc_permissions"><input type="hidden" name="user_id" value="'.(int)$id.'">';wp_nonce_field('bc_permissions','bc_nonce');foreach(bracelli_admin_caps() as $cap=>$label){echo '<p><label><input type="checkbox" name="caps[]" value="'.esc_attr($cap).'" '.checked(user_can($user,$cap),true,false).'> '.esc_html($label).'</label></p>';}submit_button('Salva permessi assegnati');echo '</form>';}
    echo '</div>';
}
function bracelli_permissions_handler(){ $result=bracelli_permissions_apply(absint($_POST['user_id']??0),isset($_POST['caps'])&&is_array($_POST['caps'])?wp_unslash($_POST['caps']):array(),isset($_POST['bc_nonce'])?wp_unslash($_POST['bc_nonce']):'');if(is_wp_error($result)){wp_die(esc_html($result->get_error_message()),'',array('response'=>403));}bracelli_admin_flash('Permessi assegnati aggiornati.');wp_safe_redirect(admin_url('admin.php?page=bc-permissions&user_id='.absint($_POST['user_id'])));exit; }
