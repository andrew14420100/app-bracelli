<?php
/** The ZIP includes the static build: no rewrite, theme, post or database change. */
if (!defined('ABSPATH')) { exit; }
function bracelli_app_url() {
    return plugins_url('app/', dirname(__DIR__) . '/bracelli-club.php');
}
function bracelli_app_api_base() {
    // Works with pretty and plain permalinks, including WordPress in a subdirectory.
    return rtrim(wp_make_link_relative(rest_url('bracelli-club/v1')), '/');
}
function bracelli_app_menu() {
    add_submenu_page('bracelli-club', 'Applicazione Bracelli Club', 'Apri app', 'bracelli_access', 'bc-app', 'bracelli_app_page');
}
function bracelli_app_page() {
    if (!bracelli_can('access')) { wp_die('Operazione non autorizzata.'); }
    echo '<div class="wrap"><h1>Applicazione Bracelli Club</h1>';
    if (!is_file(dirname(__DIR__) . '/app/index.php')) {
        echo '<p>Questa copia sorgente non include il pacchetto compilato. Installare lo ZIP completo della distribuzione.</p></div>'; return;
    }
    echo '<p>La PWA è già inclusa nel plugin. Non occorrono caricamenti aggiuntivi o compilazioni.</p><p><a class="button button-primary" href="' . esc_url(bracelli_app_url()) . '" target="_blank" rel="noopener">Apri Bracelli Club</a></p>';
    echo '<p><code>' . esc_html(bracelli_app_url()) . '</code></p><p>La PWA usa esclusivamente le API di questo WordPress. Il service worker è limitato alla cartella dell’app, separata da wp-admin.</p><p>Per l’installazione su smartphone occorre HTTPS valido. Nessun dato dimostrativo viene pubblicato automaticamente: configurare i contenuti e il modulo dal pannello.</p><p>Per i test usare solo recapiti .test e dati fittizi. La ricezione non conferma un appuntamento. Non usare il sito ufficiale per il collaudo.</p>';
    bracelli_app_capture_controls(); echo '</div>';
}
function bracelli_app_test_host() {
    $host=strtolower((string)wp_parse_url(home_url(), PHP_URL_HOST));
    return in_array(wp_get_environment_type(), array('local','development','staging'), true)
        || $host==='localhost' || $host==='127.0.0.1' || substr($host,-5)==='.test'
        || substr($host,-12)==='.tastewp.com' || substr($host,-15)==='.s2-tastewp.com';
}
function bracelli_app_capture_enabled() {
    $value=get_option('bc_app_mail_capture',array());
    return bracelli_app_test_host() && !empty($value['enabled']) && ($value['site']??'')===home_url();
}
function bracelli_app_capture_mail($pre,$mail) {
    if (!bracelli_app_capture_enabled()) { return $pre; }
    // Intercept every WordPress email, but retain only non-personal technical metadata.
    $log=array_values(array_filter((array)get_option('bc_app_mail_log',array()),function($row){return ($row['at']??0)>time()-DAY_IN_SECONDS;}));
    $log[]=array('at'=>time(),'kind'=>strpos((string)($mail['subject']??''),'Bracelli Club')===0?'Notifica Bracelli Club catturata':'Email WordPress bloccata');
    update_option('bc_app_mail_log',array_slice($log,-30),false);
    return true; // wp_mail reports accepted by the local capture, no SMTP is contacted.
}
function bracelli_app_capture_handler() {
    if (!current_user_can('manage_options')) { wp_die('Operazione non autorizzata.','',array('response'=>403)); }
    check_admin_referer('bc_app_capture');
    if (!bracelli_app_test_host()) { wp_die('La cattura è disponibile solo su un ambiente locale o staging riconosciuto.','',array('response'=>403)); }
    $enabled=isset($_POST['enabled']) && $_POST['enabled']==='1';
    if ($enabled && (!isset($_POST['test_only']) || $_POST['test_only']!=='1')) { wp_die('Confermare che questo è un WordPress temporaneo.','',array('response'=>400)); }
    update_option('bc_app_mail_capture',array('enabled'=>$enabled,'site'=>home_url()),false);
    if ($enabled) { update_option('blog_public',0); }
    wp_safe_redirect(admin_url('admin.php?page=bc-app')); exit;
}
function bracelli_app_capture_controls() {
    if (!current_user_can('manage_options')) { return; }
    echo '<h2>Collaudo senza invii esterni</h2><p>Su uno staging riconosciuto puoi intercettare tutte le email WordPress e disattivare l’indicizzazione. Non viene memorizzato il corpo delle email o alcun recapito. La bacheca mantiene il normale accesso WordPress: proteggi anche lo staging dal pannello del fornitore.</p>';
    if (!bracelli_app_test_host()) { echo '<p>Questo host non è riconosciuto come ambiente temporaneo: cattura non disponibile.</p>'; return; }
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="bc_app_capture">';
    wp_nonce_field('bc_app_capture');
    echo '<p><label><input type="checkbox" name="enabled" value="1" '.checked(bracelli_app_capture_enabled(),true,false).'> Intercetta tutte le email: nessun invio esterno</label></p><p><label><input type="checkbox" name="test_only" value="1"> Confermo che questo WordPress è temporaneo, separato dal sito ufficiale e contiene solo dati fittizi</label></p>';
    submit_button('Salva modalità di collaudo'); echo '</form>';
    echo '<p><strong>'.(bracelli_app_capture_enabled()?'Cattura attiva. Gli esiti “sent/accepted” indicano la cattura locale, non un recapito esterno.':'Cattura disattivata. WordPress utilizza il proprio trasporto email.').'</strong></p><ul>';
    if (bracelli_app_capture_enabled()) { foreach(array_reverse((array)get_option('bc_app_mail_log',array())) as $row) { if(($row['at']??0)>time()-DAY_IN_SECONDS){echo '<li>'.esc_html(gmdate('Y-m-d H:i:s',$row['at']).' UTC · '.$row['kind']).'</li>';}} }
    echo '</ul><p>Conservazione: massimo 30 eventi tecnici, visibili per 24 ore. Nessuna informazione viene esposta alle API pubbliche.</p>';
}
add_action('admin_post_bc_app_capture','bracelli_app_capture_handler');
add_filter('pre_wp_mail','bracelli_app_capture_mail',PHP_INT_MAX,2);
