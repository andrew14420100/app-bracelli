<?php
if (!defined('ABSPATH')) { exit; }
function bracelli_request_filters($input){
    $defaults=array('search'=>'','status'=>'','discipline'=>'','from'=>'','to'=>'','sort'=>'created_at','direction'=>'DESC','page'=>1);if(!is_array($input)){return new WP_Error('bc_filters','Filtri non validi.');}
    $out=$defaults;
    foreach(array('search','status','discipline','from','to','sort','direction') as $key){if(isset($input[$key])&&!is_scalar($input[$key])){return new WP_Error('bc_filters','Filtro non valido.');}if(isset($input[$key])){$out[$key]=sanitize_text_field((string)$input[$key]);}}
    if(isset($input['order'])&&is_string($input['order'])){ $parts=explode(':',$input['order']);$out['sort']=$parts[0];$out['direction']=$parts[1]??'DESC'; }
    if(!in_array($out['sort'],array('id','created_at','last_name','discipline_name','status'),true)||!in_array($out['direction'],array('ASC','DESC'),true)){return new WP_Error('bc_filters','Ordinamento non valido.');}
    if($out['status']!==''&&!isset(bracelli_trial_states()[$out['status']])){return new WP_Error('bc_filters','Stato non valido.');}
    if($out['discipline']!==''&&!ctype_digit($out['discipline'])){return new WP_Error('bc_filters','Disciplina non valida.');}
    foreach(array('from','to') as $key){if($out[$key]!==''){$date=DateTimeImmutable::createFromFormat('!Y-m-d',$out[$key],wp_timezone());if(!$date||$date->format('Y-m-d')!==$out[$key]){return new WP_Error('bc_filters','Usare date valide.');}}}
    if($out['from']!==''&&$out['to']!==''&&$out['from']>$out['to']){return new WP_Error('bc_filters','La data iniziale deve precedere quella finale.');}
    $out['page']=max(1,min(100000,absint($input['page']??$input['bc_page']??1)));$out['search']=mb_substr($out['search'],0,200);return $out;
}
function bracelli_request_where($filters){
    global $wpdb;$where='1=1';$args=array();
    if($filters['status']!==''){$where.=' AND status=%s';$args[]=$filters['status'];}
    if($filters['discipline']!==''){$where.=' AND discipline_id=%d';$args[]=(int)$filters['discipline'];}
    if(preg_match('/^#([1-9][0-9]*)$/D',$filters['search'],$exact)){$where.=' AND id=%d';$args[]=(int)$exact[1];}
    elseif($filters['search']!==''){$like='%'.$wpdb->esc_like($filters['search']).'%';$where.=' AND (first_name LIKE %s OR last_name LIKE %s OR email LIKE %s OR phone LIKE %s OR discipline_name LIKE %s OR course_name LIKE %s OR id=%d)';$args=array_merge($args,array_fill(0,6,$like),array(ctype_digit($filters['search'])?(int)$filters['search']:0));}
    foreach(array('from'=>'>=','to'=>'<') as $key=>$operator){if($filters[$key]!==''){$date=new DateTimeImmutable($filters[$key].' 00:00:00',wp_timezone());if($key==='to'){$date=$date->modify('+1 day');}$where.=' AND created_at'.$operator.'%s';$args[]=$date->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');}}
    return array($where,$args);
}
function bracelli_requests_query($input,$limit=20){
    global $wpdb;if(!bracelli_can('view_trials')){return new WP_Error('bc_forbidden','Operazione non autorizzata.');}
    $f=bracelli_request_filters($input);if(is_wp_error($f)){return $f;}list($where,$args)=bracelli_request_where($f);$table=bracelli_trial_table();
    return bracelli_trial_db(function()use($wpdb,$table,$where,$args,$f,$limit){
        $sql="SELECT COUNT(*) FROM $table WHERE $where";$total=(int)$wpdb->get_var($args?$wpdb->prepare($sql,...$args):$sql);
        $sql="SELECT * FROM $table WHERE $where ORDER BY {$f['sort']} {$f['direction']},id {$f['direction']} LIMIT %d OFFSET %d";
        $rows=$wpdb->get_results($wpdb->prepare($sql,...array_merge($args,array($limit,($f['page']-1)*$limit))),ARRAY_A);
        return is_array($rows)?array('rows'=>$rows,'total'=>$total,'filters'=>$f):new WP_Error('bc_storage','Archivio temporaneamente non disponibile.');
    });
}
function bracelli_dashboard_stats($input=array()){
    global $wpdb;if(!bracelli_can('view_trials')){return new WP_Error('bc_forbidden','Operazione non autorizzata.');}
    $f=bracelli_request_filters($input);if(is_wp_error($f)){return $f;}list($where,$args)=bracelli_request_where($f);$table=bracelli_trial_table();
    $sql="SELECT status,COUNT(*) AS total FROM $table WHERE $where GROUP BY status";
    $rows=bracelli_trial_db(function()use($wpdb,$sql,$args){return $wpdb->get_results($args?$wpdb->prepare($sql,...$args):$sql,ARRAY_A);});
    if(!is_array($rows)){return new WP_Error('bc_storage','Statistiche temporaneamente non disponibili.');}
    $counts=array_fill_keys(array_keys(bracelli_trial_states()),0);foreach((array)$rows as $row){if(isset($counts[$row['status']])){$counts[$row['status']]=(int)$row['total'];}}
    return array('total'=>array_sum($counts),'states'=>$counts,'filters'=>$f);
}
function bracelli_csv_cell($value){$value=(string)$value;$first=preg_replace('/^[\x00-\x20\s\p{Z}\x{FEFF}\x{200B}]+/u','',$value);return preg_match('/^[=+\-@]/u',$first)?"'".$value:$value;}
function bracelli_requests_csv($input){
    if(!bracelli_can('export_trials')||!bracelli_can('view_trials')){return new WP_Error('bc_forbidden','Esportazione non autorizzata.');}
    $input['page']=1;
    $result=bracelli_requests_query($input,5000);if(is_wp_error($result)){return $result;}if($result['total']>5000){return new WP_Error('bc_export_limit','Restringere i filtri: massimo 5000 righe per esportazione.');}
    $handle=fopen('php://temp','r+');$columns=array('id'=>'ID','created_at'=>'Ricezione UTC','first_name'=>'Nome referente','last_name'=>'Cognome referente','email'=>'Email','phone'=>'Telefono','discipline_name'=>'Disciplina','course_name'=>'Corso','age_band'=>'Fascia età','preferred_day'=>'Giorno preferito','status'=>'Stato','message'=>'Messaggio');
    fwrite($handle,"\xEF\xBB\xBF");fputcsv($handle,array_values($columns),';','"','');foreach($result['rows'] as $row){$cells=array();foreach($columns as $key=>$label){$cells[]=bracelli_csv_cell($row[$key]);}fputcsv($handle,$cells,';','"','');}rewind($handle);$csv=stream_get_contents($handle);fclose($handle);bracelli_admin_audit('export',$result['total']);return $csv;
}
function bracelli_requests_bulk($ids,$operation,$status,$confirmed,$nonce){
    global $wpdb;if(!bracelli_can('view_trials')||!is_string($nonce)||!wp_verify_nonce($nonce,'bc_trials_bulk')){return new WP_Error('bc_forbidden','Operazione non autorizzata.');}
    if(!in_array($operation,array('status','delete'),true)||!$confirmed||!is_array($ids)||!$ids||count($ids)>100){return new WP_Error('bc_bulk','Selezionare da 1 a 100 richieste e confermare l’operazione.');}
    if(($operation==='status'&&!bracelli_can('edit_trials'))||($operation==='delete'&&!bracelli_can('delete_data'))){return new WP_Error('bc_forbidden','Permesso insufficiente.');}
    if($operation==='status'&&!isset(bracelli_trial_states()[$status])){return new WP_Error('bc_status','Stato non valido.');}
    $clean=array();foreach($ids as $id){if(!is_scalar($id)||!ctype_digit((string)$id)||!(int)$id||!bracelli_trial_get((int)$id)){return new WP_Error('bc_bulk','Una richiesta selezionata non è disponibile.');}$clean[]=(int)$id;}$clean=array_values(array_unique($clean));
    $table=bracelli_trial_table();$engine=$wpdb->get_row($wpdb->prepare('SHOW TABLE STATUS LIKE %s',$wpdb->esc_like($table)),ARRAY_A);
    if(!$engine || strcasecmp($engine['Engine'],'InnoDB')!==0){return new WP_Error('bc_engine','Le azioni multiple richiedono una tabella InnoDB transazionale.');}
    sort($clean,SORT_NUMERIC);$locked=array();foreach($clean as $id){if(!bracelli_trial_lock($id)){foreach($locked as $held){bracelli_trial_unlock($held);}return new WP_Error('bc_busy','Una richiesta è in aggiornamento. Riprovare.');}$locked[]=$id;}
    try {
    $wpdb->query('START TRANSACTION');
    foreach($clean as $id){$row=bracelli_trial_get($id);$result=$operation==='delete'?bracelli_trial_db(function()use($wpdb,$table,$id){return $wpdb->delete($table,array('id'=>$id));}):bracelli_trial_update($id,$status,$row['notes'],wp_create_nonce('bc_trial_'.$id),false);if($result===false||is_wp_error($result)){$wpdb->query('ROLLBACK');return new WP_Error('bc_bulk','Operazione non completata; nessuna modifica parziale.');}}
    $wpdb->query('COMMIT');bracelli_admin_audit($operation==='delete'?'delete':'bulk_status',count($clean));return count($clean);
    }finally{foreach($locked as $held){bracelli_trial_unlock($held);}}
}
function bracelli_trial_export_handler(){if(!isset($_POST['bc_export_nonce'])||!is_string($_POST['bc_export_nonce'])||!wp_verify_nonce(wp_unslash($_POST['bc_export_nonce']),'bc_trial_export')){wp_die('Verifica non valida.','',array('response'=>403));}$csv=bracelli_requests_csv(wp_unslash($_POST));if(is_wp_error($csv)){wp_die(esc_html($csv->get_error_message()),'',array('response'=>403));}nocache_headers();header('Content-Type: text/csv; charset=UTF-8');header('X-Content-Type-Options: nosniff');header('Content-Disposition: attachment; filename="bracelli-richieste-'.gmdate('Y-m-d').'.csv"');echo $csv;exit;}
function bracelli_trial_bulk_handler(){ $result=bracelli_requests_bulk(isset($_POST['ids'])?wp_unslash($_POST['ids']):array(),isset($_POST['bulk_operation'])?sanitize_key($_POST['bulk_operation']):'',isset($_POST['bulk_status'])?sanitize_key($_POST['bulk_status']):'',isset($_POST['confirmed'])&&$_POST['confirmed']==='1',isset($_POST['bc_bulk_nonce'])?wp_unslash($_POST['bc_bulk_nonce']):'');if(is_wp_error($result)){wp_die(esc_html($result->get_error_message()),'',array('response'=>403));}bracelli_admin_flash('Operazione completata su '.$result.' richieste.');wp_safe_redirect(admin_url('admin.php?page=bc-trials'));exit; }
function bracelli_request_filters_form($f){
    echo '<div class="bc-filters"><label>Cerca referente, attività o ID (#123)<input type="search" name="search" value="'.esc_attr($f['search']).'"></label><label>Stato<select name="status"><option value="">Tutti</option>';foreach(bracelli_trial_states() as $key=>$label){echo '<option value="'.esc_attr($key).'" '.selected($f['status'],$key,false).'>'.esc_html($label).'</option>';}echo '</select></label><label>Disciplina<select name="discipline"><option value="">Tutte</option>';
    global $wpdb;$table=bracelli_trial_table();foreach((array)$wpdb->get_results("SELECT discipline_id,MAX(discipline_name) AS name FROM $table GROUP BY discipline_id",ARRAY_A) as $row){echo '<option value="'.(int)$row['discipline_id'].'" '.selected((string)$f['discipline'],(string)$row['discipline_id'],false).'>'.esc_html($row['name']).'</option>';}
    echo '</select></label><label>Dal<input type="date" name="from" value="'.esc_attr($f['from']).'"></label><label>Al<input type="date" name="to" value="'.esc_attr($f['to']).'"></label><button class="button" name="bc_page" value="1">Cerca e filtra</button></div>';
}
function bracelli_trials_list(){
    $input=array();if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){if(!isset($_POST['bc_nonce'])||!is_string($_POST['bc_nonce'])||!wp_verify_nonce(wp_unslash($_POST['bc_nonce']),'bc_trial_search')){wp_die('Verifica di sicurezza non valida.');}$input=wp_unslash($_POST);}
    $result=bracelli_requests_query($input);if(is_wp_error($result)){echo '<div class="notice notice-error"><p>'.esc_html($result->get_error_message()).'</p></div>';return;}$f=$result['filters'];

    echo '<form method="post" action="'.esc_url(admin_url('admin.php?page=bc-trials')).'">';wp_nonce_field('bc_trial_search','bc_nonce');wp_nonce_field('bc_trials_bulk','bc_bulk_nonce');wp_nonce_field('bc_trial_export','bc_export_nonce');wp_nonce_field('bc_trial_quick','bc_quick_nonce');bracelli_request_filters_form($f);
    echo '<p role="status">'.(int)$result['total'].' risultati · Pagina '.(int)$f['page'].'</p><div class="bc-table-wrap" tabindex="0" role="region" aria-label="Elenco richieste"><table class="widefat striped bc-table"><thead><tr><th><span class="screen-reader-text">Seleziona</span></th>';
    foreach(array('id'=>'ID','created_at'=>'Ricevuta','last_name'=>'Referente','discipline_name'=>'Attività','status'=>'Stato') as $key=>$label){$direction=$f['sort']===$key&&$f['direction']==='ASC'?'DESC':'ASC';echo '<th scope="col"><button class="button-link" name="order" value="'.esc_attr($key.':'.$direction).'">'.esc_html($label).' ↕</button></th>';}echo '<th scope="col">Notifica</th></tr></thead><tbody>';
    foreach($result['rows'] as $row){echo '<tr class="'.(in_array($row['status'],array('new','contact'),true)?'bc-unhandled':'').'" data-request-id="'.(int)$row['id'].'"><td><label><span class="screen-reader-text">Seleziona richiesta '.(int)$row['id'].'</span><input type="checkbox" name="ids[]" value="'.(int)$row['id'].'"></label></td><td><a href="'.esc_url(admin_url('admin.php?page=bc-trials&request='.(int)$row['id'])).'">#'.(int)$row['id'].'</a></td><td>'.esc_html($row['created_at']).' UTC</td><td>'.esc_html($row['first_name'].' '.$row['last_name']).'</td><td>'.esc_html($row['discipline_name'].' · '.$row['course_name']).'</td><td><span class="bc-badge">'.esc_html(bracelli_trial_states()[$row['status']]).'</span>';
        if(bracelli_can('edit_trials')){echo '<label class="screen-reader-text" for="quick-state-'.(int)$row['id'].'">Stato richiesta '.(int)$row['id'].'</label><select id="quick-state-'.(int)$row['id'].'" name="quick_status['.(int)$row['id'].']">';foreach(bracelli_trial_states() as $state=>$label){echo '<option value="'.esc_attr($state).'" '.selected($row['status'],$state,false).'>'.esc_html($label).'</option>';}echo '</select><input type="hidden" name="quick_revision['.(int)$row['id'].']" value="'.esc_attr(bracelli_trial_revision($row)).'"><button class="button" aria-label="Salva stato richiesta '.(int)$row['id'].'" name="quick_id" value="'.(int)$row['id'].'" formaction="'.esc_url(admin_url('admin-post.php?action=bc_trial_quick')).'">Salva</button>';}
        echo '</td><td>'.esc_html($row['mail_status']==='failed'?'Invio da verificare':$row['mail_status']).'</td></tr>';}
    if(!$result['rows']){echo '<tr><td colspan="7">Nessuna richiesta corrispondente.</td></tr>';}echo '</tbody></table></div><div class="bc-actions">';
    if($f['page']>1){echo '<button class="button" name="bc_page" value="'.($f['page']-1).'">Precedente</button>';}if($f['page']*20<$result['total']){echo '<button class="button" name="bc_page" value="'.($f['page']+1).'">Successiva</button>';}
    echo '<input type="hidden" name="sort" value="'.esc_attr($f['sort']).'"><input type="hidden" name="direction" value="'.esc_attr($f['direction']).'">';
    if(bracelli_can('export_trials')){echo '<button class="button" name="action" value="bc_trial_export" formaction="'.esc_url(admin_url('admin-post.php')).'">Esporta CSV filtrato</button>';}
    echo '</div>';
    if(bracelli_can('edit_trials')||bracelli_can('delete_data')){echo '<fieldset class="bc-bulk"><legend>Azioni sulle richieste selezionate</legend><label>Azione<select name="bulk_operation">';if(bracelli_can('edit_trials')){echo '<option value="status">Cambia stato</option>';}if(bracelli_can('delete_data')){echo '<option value="delete">Elimina definitivamente</option>';}echo '</select></label><label>Nuovo stato<select name="bulk_status">';foreach(bracelli_trial_states() as $key=>$label){echo '<option value="'.esc_attr($key).'">'.esc_html($label).'</option>';}echo '</select></label><label><input type="checkbox" name="confirmed" value="1"> Confermo l’operazione sulle richieste selezionate; l’eliminazione è irreversibile</label><p class="bc-selection-count" role="status">0 richieste selezionate</p><button class="button" name="action" value="bc_trials_bulk" formaction="'.esc_url(admin_url('admin-post.php')).'">Applica alle selezionate</button></fieldset>';}
    echo '</form>';
}

function bracelli_trial_quick($id,$status,$revision,$nonce){
    if(!bracelli_can('edit_trials')||!bracelli_can('view_trials')||!is_string($nonce)||!wp_verify_nonce($nonce,'bc_trial_quick')||!is_string($revision)||$revision===''){return new WP_Error('bc_forbidden','Aggiornamento rapido non autorizzato.');}
    $row=bracelli_trial_get($id);if(!$row){return new WP_Error('bc_missing','Richiesta non disponibile.');}return bracelli_trial_update($id,$status,$row['notes'],wp_create_nonce('bc_trial_'.$id),true,$revision);
}
function bracelli_trial_quick_handler(){
    $id=absint($_POST['quick_id']??0);$result=bracelli_trial_quick($id,isset($_POST['quick_status'][$id])?wp_unslash($_POST['quick_status'][$id]):'',isset($_POST['quick_revision'][$id])?wp_unslash($_POST['quick_revision'][$id]):'',isset($_POST['bc_quick_nonce'])?wp_unslash($_POST['bc_quick_nonce']):'');if(is_wp_error($result)){wp_die(esc_html($result->get_error_message()),'',array('response'=>409));}bracelli_admin_flash('Stato richiesta aggiornato.');wp_safe_redirect(admin_url('admin.php?page=bc-trials'));exit;
}
