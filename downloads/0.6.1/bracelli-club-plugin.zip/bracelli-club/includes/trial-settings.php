<?php
if (!defined('ABSPATH')) { exit; }
function bracelli_trial_defaults() {
    return array('enabled'=>false,'notification_email'=>'','phone'=>'','whatsapp'=>'','email'=>'','address'=>'','directions'=>'','office_hours'=>'','controller'=>'','privacy_email'=>'','legal_basis'=>'','processors'=>'','privacy_extra'=>'','privacy_url'=>'','retention_days'=>90);
}
function bracelli_trial_phone($value) {
    if (!is_string($value) || !preg_match('/^\+?[0-9 ()\-.]+$/D',$value)) { return ''; }
    $clean=preg_replace('/[ ()\-.]/','',$value);
    return preg_match('/^\+?[0-9]{7,15}$/D',$clean) ? $clean : '';
}
function bracelli_trial_url($value) {
    if ($value==='') { return ''; }
    $parts=wp_parse_url($value);
    return is_array($parts) && isset($parts['host'],$parts['scheme']) && in_array(strtolower($parts['scheme']),array('http','https'),true) && !isset($parts['user']) && !isset($parts['pass']) ? esc_url_raw($value,array('http','https')) : '';
}
function bracelli_trial_validate_settings($input) {
    if (!is_array($input)) { return new WP_Error('bc_trial_settings','Configurazione non valida.'); }
    $clean=bracelli_trial_defaults();
    foreach ($clean as $key=>$default) {
        $value=$input[$key] ?? $default;
        if ($key==='enabled') { $clean[$key]=in_array($value,array(true,1,'1'),true); continue; }
        if (!is_scalar($value)) { return new WP_Error('bc_trial_settings','Valore di configurazione non valido.'); }
        $value=trim((string)$value);
        if ($key==='retention_days') {
            if (!preg_match('/^\d{1,3}$/D',$value) || (int)$value<7 || (int)$value>365) { return new WP_Error('bc_trial_settings','Conservazione: da 7 a 365 giorni.'); }
            $clean[$key]=(int)$value;continue;
        }
        if($key==='notification_email'){$recipients=bracelli_trial_recipients($value);if($value!==''&&!$recipients){return new WP_Error('bc_trial_settings','Inserire da 1 a 5 destinatari email validi, separati da virgola.');}$clean[$key]=implode(', ',$recipients);continue;}
        if (in_array($key,array('email','privacy_email'),true)) {
            if ($value!=='' && (!is_email($value) || preg_match('/[\r\n]/',$value))) { return new WP_Error('bc_trial_settings','Indirizzo email di configurazione non valido.'); }
            $clean[$key]=strtolower(sanitize_email($value));continue;
        }
        if (in_array($key,array('phone','whatsapp'),true)) {
            $normalized=$value==='' ? '' : bracelli_trial_phone($value);
            if ($value!=='' && ($normalized==='' || ($key==='whatsapp' && !preg_match('/^\+[1-9][0-9]{6,14}$/D',$normalized)))) { return new WP_Error('bc_trial_settings','Telefono non valido; WhatsApp richiede prefisso internazionale con +.'); }
            $clean[$key]=$normalized;continue;
        }
        if (in_array($key,array('directions','privacy_url'),true)) {
            $clean[$key]=bracelli_trial_url($value);
            if ($value!=='' && $clean[$key]==='') { return new WP_Error('bc_trial_settings','URL non valido: usare http/https senza credenziali.'); }
            continue;
        }
        $clean[$key]=sanitize_textarea_field($value);
        if (mb_strlen($clean[$key])>4000) { return new WP_Error('bc_trial_settings','Testo di configurazione troppo lungo.'); }
    }
    if ($clean['enabled']) {
        foreach (array('notification_email','controller','privacy_email','legal_basis','processors') as $key) { if ($clean[$key]==='') { return new WP_Error('bc_trial_settings','Per abilitare il modulo completare destinatario email, titolare, contatto privacy, base giuridica e destinatari/responsabili.'); } }
    }
    return $clean;
}
function bracelli_trial_settings() {
    $value=bracelli_trial_validate_settings(get_option('bc_trial_settings',array()));
    return is_wp_error($value) ? bracelli_trial_defaults() : $value;
}
function bracelli_trial_notice($settings) {
    $text='Titolare del trattamento: '.$settings['controller']."\n\n";
    $text.="Finalità: gestire la richiesta di lezione di prova e ricontattare il referente per concordare un eventuale appuntamento. La ricezione non prenota posti e non conferma un appuntamento.\n\n";
    $text.='Base giuridica: '.$settings['legal_basis']."\n\n";
    $text.="Dati: nome e cognome del referente adulto, email, telefono, attività scelta, eventuale fascia d’età del partecipante, giorno preferito e messaggio. Non sono richiesti dati identificativi del minore o dati sanitari. I recapiti sono necessari per gestire la richiesta; giorno e messaggio sono facoltativi. Nessun consenso promozionale viene richiesto.\n\n";
    $text.='Destinatari, responsabili e trasferimenti: '.$settings['processors']."\n\n";
    $text.='Conservazione programmata: '.$settings['retention_days']." giorni dalla ricezione; le richieste scadute vengono eliminate con la pulizia giornaliera. Puoi chiedere la cancellazione anticipata.\n\n";
    $text.='Per esercitare accesso, rettifica, cancellazione, limitazione, portabilità e opposizione nei casi previsti dalla legge, scrivi a '.$settings['privacy_email'].". Puoi proporre reclamo all’autorità di controllo competente.\n\n";
    $text.=$settings['privacy_extra'];
    return trim($text);
}
function bracelli_trial_policy($settings) {
    $text=bracelli_trial_notice($settings);
    return array('text'=>$text,'version'=>hash('sha256',$text.'|'.$settings['privacy_url']),'url'=>$settings['privacy_url']);
}
function bracelli_trial_apply_settings($input,$nonce) {
    if (!bracelli_can('manage_settings') || !is_string($nonce) || !wp_verify_nonce($nonce,'bc_trial_settings')) { return new WP_Error('bc_forbidden','Operazione non autorizzata.'); }
    $clean=bracelli_trial_validate_settings($input);if(is_wp_error($clean)){return $clean;}
    update_option('bc_trial_settings',$clean,false);bracelli_admin_audit('trial_settings');return $clean;
}

function bracelli_trial_recipients($value){
    if(!is_string($value)||trim($value)===''){return array();}$emails=array_values(array_unique(array_map(function($email){return strtolower(trim($email));},preg_split('/[,;]/',$value))));if(count($emails)>5){return array();}foreach($emails as $email){if(!is_email($email)||preg_match('/[\r\n]/',$email)){return array();}}return array_map('strtolower',$emails);
}
